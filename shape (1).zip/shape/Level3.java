
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;import javax.imageio.ImageIO;

import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Level3 extends JPanel implements ActionListener, KeyListener {
    // Game dimensions and settings
    int panelWidth = 450;
    int panelHeight = 580;
    int shapeSize = 65;
    int shapeX, shapeY;
    int slotY;
    int heptagonSlotX = 75;

    int rhombusSlotX = 150;
    int parallelogramSlotX = 225;
    int octagonSlotX = 300;
    int pentagonSlotX = 375;

    // Game state variables
    int score = 0;
    int sorted = 0;
    int totalToWin = 2; // Increased for Level 3
    int timeLeft = 120; // More time for Level 3
    Timer count;
    int tolerance = 10; // Adjusted tolerance for Level 3 (was 4, now 10)
    int visualGuide = 10;

    // Images
    BufferedImage backgroundImage;
    BufferedImage leaf, tree, stone; // Reusing these for simplicity, could be space-themed obstacles
    BufferedImage heptagon, triangle, square, rhombus, parallelogram, octagon, pentagon;

    // Game state flags
    public boolean freezeShape = false;
    boolean gameStarted = false;
    boolean gameWin = false;
    boolean gameOver = false;
    boolean shapeProc = false;

    // Shape and scoring variables
    String currentShape;
    int heptagonSort = 0, squareSort = 0, triangleSort = 0, rhombusSort = 0, parallelogramSort = 0, octagonSort = 0, pentagonSort = 0;
    int missedHeptagon = 0, missedSquare = 0, missedTriangle = 0, missedRhombus = 0, missedParallelogram = 0, missedOctagon = 0, missedPentagon = 0;
    int fallingShape = 6; // Slower for Level 3

    // Obstacle variables (reusing for now, could be more complex for Level 3)
    int leafX, leafY, treeX, treeY, stoneX, stoneY;
    int leafSize = 55, treeSize = 45, stoneSize = 55;
    int obstacleDown = 20;

    // Game arrays - Level 3 includes octagon and pentagon
    String[] shapes = {"heptagon", "Octagon", "Rhombus", "Parallelogram" , "Pentagon"};
    String[] slotShape = { "Pentagon" ,"heptagon", "Rhombus", "Parallelogram", "Octagon"};
    int[] slotPos = {rhombusSlotX, heptagonSlotX, parallelogramSlotX, octagonSlotX, pentagonSlotX};
    int shapeIndex = 0;

    // UI Components
    public JButton restart;
    public JButton backToMenu;
    public JButton nextLevel; // New button for next level
    public Clip matchSound;
    public Timer timer;

    private Main parentFrame; // Changed to Main
    private GamePanel level1Panel; // Reference to Level 1 panel (not directly used here, but kept for consistency)

    public Level3(Main parentFrame, GamePanel level1Panel) { // Changed to Main
        this.parentFrame = parentFrame;
        this.level1Panel = level1Panel;
        setPreferredSize(new Dimension(1000, 700));
        setBackground(Color.BLACK);
        setLayout(null);
        initializeButtons();
        timer = new Timer(30, this); // Faster timer for Level 3
        addKeyListener(this);
        createShapeBufferedImages();
        loadBufferedImages();
        setFocusable(true);
    }

    private void initializeButtons() {
        restart = new JButton("Restart");
        restart.setBounds(panelWidth + 50, panelHeight / 2, 90, 50);
        restart.setForeground(Color.CYAN);
        restart.addActionListener(e -> restart());
        restart.setVisible(false);
        this.add(restart);

        backToMenu = new JButton("Main Menu");
        backToMenu.setBounds(panelWidth + 150, panelHeight / 2, 100, 50);
        backToMenu.setForeground(Color.ORANGE);
        backToMenu.addActionListener(e -> returnToMainMenu());
        backToMenu.setVisible(false);
        this.add(backToMenu);

        nextLevel = new JButton("Next Level");
        nextLevel.setBounds(panelWidth + 250, panelHeight / 2, 100, 50);
        nextLevel.setForeground(Color.GREEN);
        nextLevel.addActionListener(e -> startNextLevel());
        nextLevel.setVisible(false);
        this.add(nextLevel);
    }

    private void returnToMainMenu() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        // Clear buttons before returning to menu to prevent duplication
        removeAll();
        revalidate();
        repaint();
        parentFrame.returnToMenu(); // Call method in Main to return to main menu
    }

    private void startNextLevel() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        // Clear buttons before starting next level
        removeAll();
        revalidate();
        repaint();
        parentFrame.startLevel(4); // Assuming Level 4 is the next level
    }

    public void createShapeBufferedImages() {
        // Create heptagon
        heptagon = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = heptagon.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.GREEN);  int[] hepX = new int[7];
        int[] hepY = new int[7];
        int centerX = shapeSize / 2;
        int centerY = shapeSize / 2;
        int radius = shapeSize / 2 - 2;
        for (int i = 0; i < 7; i++) {
            double angle = 2 * Math.PI * i / 7;
            hepX[i] = centerX + (int) (radius * Math.cos(angle));
            hepY[i] = centerY + (int) (radius * Math.sin(angle));
        }
        g2d.fillPolygon(hepX, hepY, 7);
        g2d.setColor(Color.YELLOW.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(hepX, hepY, 7);
        g2d.dispose();
       g2d.fillOval(0, 0, shapeSize, shapeSize);
    g2d.setColor(Color.BLACK);
//        g2d.setStroke(new BasicStroke(2));
      g2d.drawOval(1, 1, shapeSize - 2, shapeSize - 2);
       g2d.dispose();
       // Create rhombus
        rhombus = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = rhombus.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.MAGENTA);
        int[] rhombusX = {shapeSize / 2, shapeSize, shapeSize / 2, 0};
        int[] rhombusY = {0, shapeSize / 2, shapeSize, shapeSize / 2};
        g2d.fillPolygon(rhombusX, rhombusY, 4);
        g2d.setColor(Color.MAGENTA.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(rhombusX, rhombusY, 4);
        g2d.dispose();

        // Create parallelogram
        parallelogram = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = parallelogram.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.CYAN);
        int[] paraX = {8, shapeSize, shapeSize - 8, 0};
        int[] paraY = {0, 0, shapeSize, shapeSize};
        g2d.fillPolygon(paraX, paraY, 4);
        g2d.setColor(Color.CYAN.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(paraX, paraY, 4);
        g2d.dispose();

        // Create octagon
        octagon = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = octagon.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.YELLOW);
        int[] octX = new int[8];
        int[] octY = new int[8];
        int centerOcX = shapeSize / 2;
        int centerOcY = shapeSize / 2;
        int radiusOc = shapeSize / 2 - 2;
        for (int i = 0; i < 8; i++) {
            double angle = 2 * Math.PI * i / 8;
            octX[i] = centerOcX + (int) (radiusOc* Math.cos(angle));
            octY[i] = centerOcY + (int) (radiusOc* Math.sin(angle));
        }
        g2d.fillPolygon(octX, octY, 8);
        g2d.setColor(Color.YELLOW.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(octX, octY, 8);
        g2d.dispose();

        // Create pentagon
        pentagon = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = pentagon.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.PINK);
        int[] pentX = new int[5];
        int[] pentY = new int[5];
        centerX = shapeSize / 2;
        centerY = shapeSize / 2;
        radius = shapeSize / 2 - 2;
        for (int i = 0; i < 5; i++) {
            double angle = 2 * Math.PI * i / 5 - Math.PI / 2; // Start from top
            pentX[i] = centerX + (int) (radius * Math.cos(angle));
            pentY[i] = centerY + (int) (radius * Math.sin(angle));
        }
        g2d.fillPolygon(pentX, pentY, 5);
        g2d.setColor(Color.PINK.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(pentX, pentY, 5);
        g2d.dispose();
    }

    private void loadBufferedImages() {
        try {
            leaf = ImageIO.read(getClass().getResource("/leaf.png"));
            tree = ImageIO.read(getClass().getResource("/tree.png"));
            stone = ImageIO.read(getClass().getResource("/stone.png"));
            backgroundImage = ImageIO.read(getClass().getResource("/lv3.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
            createFallbackImages();
        }
    }

    private void createFallbackImages() {
        // Create fallback background with cosmic theme
        backgroundImage = new BufferedImage(panelWidth, panelHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = backgroundImage.createGraphics();
        GradientPaint gradient = new GradientPaint(0, 0, new Color(25, 25, 112), panelWidth, panelHeight, new Color(72, 61, 139));
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, panelWidth, panelHeight);
        // Add some "stars"
        g2d.setColor(Color.WHITE);
        for (int i = 0; i < 50; i++) {
            int x = (int) (Math.random() * panelWidth);
            int y = (int) (Math.random() * panelHeight);
            g2d.fillOval(x, y, 2, 2);
        }
        g2d.dispose();

        // Create simple obstacle images
        leaf = createSimpleObstacle(leafSize, Color.GREEN);
        tree = createSimpleObstacle(treeSize, new Color(139, 69, 19));
        stone = createSimpleObstacle(stoneSize, Color.GRAY);
    }

    private BufferedImage createSimpleObstacle(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(color);
        g2d.fillOval(0, 0, size, size);
        g2d.setColor(color.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawOval(1, 1, size - 2, size - 2);
        g2d.dispose();
        return img;
    }

    public void startGame() {
        gameStarted = true;
        gameOver = false;
        gameWin = false;
        score = 0;
        sorted = 0;
        timeLeft = 120;
        // Reset all counters
        heptagonSort = rhombusSort = parallelogramSort = octagonSort = pentagonSort = 0;
        missedHeptagon = missedRhombus = missedParallelogram = missedOctagon = missedPentagon = 0;
        shapeIndex = 0;

        slotY = panelHeight - 30;

        spawnNewShape();
        spawnObstacles();

        if (count != null) count.stop();
        count = new Timer(1000, e -> {
            if (!gameOver && !gameWin) {
                timeLeft--;
                if (timeLeft <= 0) {
                    gameOver = true;
                    count.stop();
                    timer.stop();
                    repaint();
                }
            }
        });
        count.start();
        timer.start();
        requestFocusInWindow();
        repaint();
    }

    public void restart() {
        startGame();
    }

    public void spawnObstacles() {
        leafX = panelWidth / 2 - 30;
        leafY = 75;
        treeX = panelWidth / 2 + 70;
        treeY = 100;
        stoneX = panelWidth / 2;
        stoneY = 350;
    }

    public void shuffle() {
        java.util.List<String> shapeList = new ArrayList<>(Arrays.asList(slotShape));
        java.util.List<Integer> posList = new ArrayList<>();
        for (int pos : slotPos) {
            posList.add(pos);
        }
        // Shuffle both lists using Collections.shuffle (Fisher-Yates algorithm)
        Collections.shuffle(shapeList);
        Collections.shuffle(posList);
        for (int i = 0; i < slotShape.length; i++) {
            slotShape[i] = shapeList.get(i);
            slotPos[i] = posList.get(i);
        }
    }

    public void spawnNewShape() {
        currentShape = shapes[shapeIndex];
        shapeX = panelWidth / 2;
        shapeY = 0;
        shapeIndex++;
        if (shapeIndex >= shapes.length) {
            shapeIndex = 0;
        }
        shuffle();
        freezeShape = false;
        shapeProc = false;
    }

    public void moveObstaclesDown() {
        leafY += obstacleDown;
        treeY += obstacleDown;
        stoneY += obstacleDown;

        if (leafY > panelHeight - 100) {
            leafY = 50 + (int) (Math.random() * 50);
            leafX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (treeY > panelHeight - 100) {
            treeY = 50 + (int) (Math.random() * 50);
            treeX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (stoneY > panelHeight - 100) {
            stoneY = 50 + (int) (Math.random() * 50);
            stoneX = 50 + (int) (Math.random() * (panelWidth - 100));
        }

        // Randomly shuffle obstacle positions
        if (Math.random() > 0.5) {
            int tempX = leafX;
            leafX = treeX;
            treeX = tempX;
        }
        if (Math.random() > 0.5) {
            int tempX = stoneX;
            stoneX = leafX;
            leafX = tempX;
        }
    }

    private BufferedImage getCurrentShapeImage() {
        switch (currentShape) {
            case "heptagon":
                return heptagon;


            case "Rhombus":
                return rhombus;
            case "Parallelogram":
                return parallelogram;
            case "Octagon":
                return octagon;
            case "Pentagon":
                return pentagon;
            default:
                return null;
        }
    }

    private boolean checkCollision(BufferedImage obstacle, int obstacleX, int obstacleY, int obstacleWidth, int obstacleHeight) {
        // Simple bounding box collision for performance
        int shapeLeft = shapeX;
        int shapeRight = shapeX + shapeSize;
        int shapeTop = shapeY;
        int shapeBottom = shapeY + shapeSize;

        int obstacleLeft = obstacleX;
        int obstacleRight = obstacleX + obstacleWidth;
        int obstacleTop = obstacleY;
        int obstacleBottom = obstacleY + obstacleHeight;

        return !(shapeRight < obstacleLeft || shapeLeft > obstacleRight ||
                shapeBottom < obstacleTop || shapeTop > obstacleBottom);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }

        if (!freezeShape) {
            shapeY += fallingShape;

            // Check collision with obstacles
            if (checkCollision(leaf, leafX, leafY, leafSize, leafSize) ||
                    checkCollision(tree, treeX, treeY, treeSize, treeSize) ||
                    checkCollision(stone, stoneX, stoneY, stoneSize, stoneSize)) {
                freezeShape = true;
            }
        }

        // Check if shape reached the bottom slots
        if (shapeY + shapeSize >= slotY && !shapeProc) {
            if (isShapeInCorrectSlot()) {
                int pointsEarned = getPointsEarned();
                score += pointsEarned;
               // System.out.println("GamePanel (Level 3): Shape matched! Earned " + pointsEarned + " points. Current score: " + score); // Debug print
                sorted++;

                // Update shape-specific counters
                if (currentShape.equals("heptagon")) {
                    heptagonSort++;
                }

                 else if (currentShape.equals("Rhombus")) {
                    rhombusSort++;
                } else if (currentShape.equals("Parallelogram")) {
                    parallelogramSort++;
                } else if (currentShape.equals("Octagon")) {
                    octagonSort++;
                } else if (currentShape.equals("Pentagon")) {
                    pentagonSort++;
                }
                shapeProc = true;
                shuffle();
                moveObstaclesDown();

                if (sorted >= totalToWin) {
                    gameWin = true;
                    timer.stop();
                    //count.stop();
                    SwingUtilities.invokeLater(() -> {
                       // parentFrame.addToTotalScore(score); // Add score to total
                        parentFrame.unlockLevel(4, score); // Unlock Level 4
                    });
                    repaint();
                    return;
                }
                spawnNewShape();
            }}
        if (shapeY > panelHeight + shapeSize && !shapeProc) {
            score -= 5;
            moveObstaclesDown();
            if (currentShape.equals("heptagon")) {
                missedHeptagon++;
            }

            else if (currentShape.equals("Parallelogram")) {
                missedParallelogram++;
            } else if (currentShape.equals("Rhombus")) {
                missedRhombus++;
            }else if (currentShape.equals("Pentagon")) {
                missedPentagon++;
            }else if (currentShape.equals("Octagon")) {
                missedOctagon++;
            }
            shapeProc = true;
            spawnNewShape();
        }
        repaint();
  }

  private int getPointsEarned() {
        int basePoints;
        switch (currentShape) {
            case "heptagon":
                basePoints = 50;
                break;


            case "Rhombus":
                basePoints = 60;
                break;
            case "Parallelogram":
                basePoints = 70;
                break;
            case "Octagon":
                basePoints = 80;
                break; // Higher points for cosmic shapes
            case "Pentagon":
                basePoints = 90;
                break;
            default:
                basePoints = 10;
        }
        // Bonus points for time remaining
        int timeBonus = Math.max(0, timeLeft / 20);
        return basePoints + timeBonus;
    }

    private boolean isShapeInCorrectSlot() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return isShapePerfectlyAligned(slotPos[i]);
            }
        }
        return false;
    }

    private boolean isShapePerfectlyAligned(int targetSlotX) {
        boolean xMatch = Math.abs(shapeX - targetSlotX) <= tolerance;
        boolean yMatch = Math.abs(shapeY - slotY) <= tolerance;
        return xMatch && yMatch;
    }

    private int getTargetSlotX() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return slotPos[i];
            }
        }
        return -1;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw background
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }

        if (gameStarted && !gameOver && !gameWin) {
            // Draw current falling shape
            BufferedImage currentShapeImg = getCurrentShapeImage();
            if (currentShapeImg != null) {
                g.drawImage(currentShapeImg, shapeX, shapeY, shapeSize, shapeSize, this);
            }

            // Draw slots
            drawSlots(g);

            // Draw obstacles
            if (leaf != null) g.drawImage(leaf, leafX, leafY, leafSize, leafSize, this);
            if (tree != null) g.drawImage(tree, treeX, treeY, treeSize, treeSize, this);
            if (stone != null) g.drawImage(stone, stoneX, stoneY, stoneSize, stoneSize, this);

            // Draw visual guides
            drawVisualGuides(g);
        }

        // Draw game stats
        drawGameStats(g);

        // Draw game over/win screens
        if (gameOver) {
            drawGameOverScreen(g);
        } else if (gameWin) {
            drawWinScreen(g);
        }
    }

    private void drawSlots(Graphics g) {
        for (int i = 0; i < slotShape.length; i++) {
            switch (slotShape[i]) {
                case "heptagon":
                    g.setColor(Color.MAGENTA);
                    int[] hepX = new int[7];
                    int[] hepY = new int[7];
                    int centerX = slotPos[i] + shapeSize / 2;
                    int centerY = slotY + shapeSize / 2;
                    int radius = shapeSize / 2 - 2;
                    for (int j = 0; j < 7; j++) {
                        double angle = 2 * Math.PI * j / 7;
                        hepX[j] = centerX + (int) (radius * Math.cos(angle));
                        hepY[j] = centerY + (int) (radius * Math.sin(angle));
                    }
                    g.fillPolygon(hepX, hepY, 7);
                    if (currentShape.equals("Octagon")) {
                        g.setColor(Color.ORANGE);
                        g.drawPolygon(hepX, hepY, 7);
                    }
                    break;

                case "Rhombus":
                    g.setColor(Color.LIGHT_GRAY);
                    int[] rhombusX = {slotPos[i] + shapeSize / 2, slotPos[i] + shapeSize, slotPos[i] + shapeSize / 2, slotPos[i]};
                    int[] rhombusY = {slotY, slotY + shapeSize / 2, slotY + shapeSize, slotY + shapeSize / 2};
                    g.fillPolygon(rhombusX, rhombusY, 4);
                    if (currentShape.equals("Rhombus")) {
                        g.setColor(Color.BLACK);
                        g.drawPolygon(rhombusX, rhombusY, 4);
                    }
                    break;
                case "Parallelogram":
                    g.setColor(new Color(89, 65, 29));
                    int[] paraX = {slotPos[i] + 8, slotPos[i] + shapeSize, slotPos[i] + shapeSize - 8, slotPos[i]};
                    int[] paraY = {slotY, slotY, slotY + shapeSize, slotY + shapeSize};
                    g.fillPolygon(paraX, paraY, 4);
                    if (currentShape.equals("Parallelogram")) {
                        g.setColor(Color.ORANGE);
                        g.drawPolygon(paraX, paraY, 4);
                    }
                    break;
                case "Octagon":
                    g.setColor(new Color(73, 0, 90));
                    int[] octX = new int[8];
                    int[] octY = new int[8];
                    int cX = slotPos[i] + shapeSize / 2;
                    int cY = slotY + shapeSize / 2;
                    int radiusSlot = shapeSize / 2 - 2;
                    for (int j = 0; j < 8; j++) {
                        double angle = 2 * Math.PI * j / 8;
                        octX[j] = cX + (int) (radiusSlot * Math.cos(angle));
                        octY[j] = cY + (int) (radiusSlot * Math.sin(angle));
                    }
                    g.fillPolygon(octX, octY, 8);
                    if (currentShape.equals("Octagon")) {
                        g.setColor(Color.ORANGE);
                        g.drawPolygon(octX, octY, 8);
                    }
                    break;
                case "Pentagon":
                    g.setColor(new Color(0x00233C));
                    int[] pentX = new int[5];
                    int[] pentY = new int[5];
                    centerX = slotPos[i] + shapeSize / 2;
                    centerY = slotY + shapeSize / 2;
                    radius = shapeSize / 2 - 2;
                    for (int j = 0; j < 5; j++) {
                        double angle = 2 * Math.PI * j / 5 - Math.PI / 2;
                        pentX[j] = centerX + (int) (radius * Math.cos(angle));
                        pentY[j] = centerY + (int) (radius * Math.sin(angle));
                    }
                    g.fillPolygon(pentX, pentY, 5);
                    if (currentShape.equals("Pentagon")) {
                        g.setColor(Color.ORANGE);
                        g.drawPolygon(pentX, pentY, 5);
                    }
                    break;
            }
        }
    }

    private void drawVisualGuides(Graphics g) {
        int targetSlotX = getTargetSlotX();
        if (targetSlotX != -1) {
            g.setColor(new Color(255, 255, 0, 50));
            // Vertical guide
            if (Math.abs(shapeX - targetSlotX) <= visualGuide) {
                g.fillRect(targetSlotX, 0, shapeSize, panelHeight);
                g.setColor(Color.WHITE); // Ensure text color is visible
                g.drawString(Math.abs(shapeX - targetSlotX) + "px", targetSlotX + shapeSize + 5, shapeY + shapeSize / 2);
            }
            // Horizontal guide
            if (Math.abs(shapeY - slotY) <= visualGuide) {
                g.fillRect(0, slotY, panelWidth, shapeSize);
                g.setColor(Color.WHITE); // Ensure text color is visible
                g.drawString(Math.abs(shapeY - slotY) + "px", shapeX + shapeSize + 5, shapeY + shapeSize / 2);
            }
            // Perfect alignment indicator
            if (Math.abs(shapeX - targetSlotX) <= tolerance && Math.abs(shapeY - slotY) <= tolerance) {
                g.setColor(new Color(0, 255, 0, 100));
                g.fillRect(targetSlotX - 2, slotY - 2, shapeSize + 4, shapeSize + 4);
            }
        }
    }

    private void drawGameStats(Graphics g) {
        if (gameStarted) {
            g.setColor(new Color(0, 0, 0, 180));
            g.fillRoundRect(700, 50, 200, 300, 30, 20);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 16));
            int tX = 715;
            int tY = 70;
            int gapText = 20;
            g.setColor(Color.YELLOW);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("LEVEL 3 ", tX, tY);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
            g.drawString("Score: " + score, tX, tY + gapText);
            g.drawString("Sorted: " + sorted + "/" + totalToWin, tX, tY + gapText * 2);
            g.drawString("Time: " + timeLeft + "s", tX, tY + gapText * 3);
            g.drawString(" Heptagon:  ✅ " + heptagonSort + " ❌ " + missedHeptagon, tX, tY + gapText * 5);

            g.drawString("🔹✅ " + rhombusSort + " ❌" + missedRhombus, tX, tY + gapText * 7);
            g.drawString("Parallelogram: ✅ " + parallelogramSort + " ❌" + missedParallelogram, tX, tY + gapText * 9);
            g.drawString("Pentagon: ✅ " + pentagonSort + " ❌" + missedPentagon, tX, tY + gapText * 10);
            g.drawString("Octagon: ✅ " + octagonSort + " ❌" + missedOctagon, tX, tY + gapText * 12);
        }
    }

    private void drawGameOverScreen(Graphics g) {
        // Remove existing buttons to prevent duplication
        removeAll();
        revalidate();
        repaint();

        g.setColor(new Color(0, 0, 0, 200));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 48));
      //  FontMetrics fm = g.getFontMetrics();
        String gameOverText = "GAME OVER";
     //   int x = (panelWidth - fm.stringWidth(gameOverText)) / 2;
        g.drawString(gameOverText, panelWidth/2, panelHeight / 2 - 50);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
       // fm = g.getFontMetrics();
        String scoreText = "Final Score: " + score;
      //  x = (panelWidth - fm.stringWidth(scoreText)) / 2;
        g.drawString(scoreText, panelWidth/2, panelHeight / 2);

        // Re-add buttons after clearing
        add(restart);
        add(backToMenu);
        restart.setVisible(true);
        backToMenu.setVisible(true);
    }

    private void drawWinScreen(Graphics g) {
        // Remove existing buttons to prevent duplication
        removeAll();
        revalidate();
        repaint();

        g.setColor(new Color(0, 100, 0, 200));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.YELLOW);
        g.setFont(new Font("Arial", Font.BOLD, 48));

        String winText = "YOU WIN!";
     //   int x = (panelWidth - fm.stringWidth(winText)) / 2;
        g.drawString(winText, panelWidth/2-50, panelHeight / 2 - 50);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        //fm = g.getFontMetrics();
        String scoreText = "Score: " + score;
        //x = (panelWidth - fm.stringWidth(scoreText)) / 2;
        g.drawString(scoreText, panelWidth/2, panelHeight / 2);

        // Re-add buttons after clearing
        add(restart);
        add(backToMenu);
        add(nextLevel); // Add next level button
        restart.setVisible(true);
        backToMenu.setVisible(true);
        nextLevel.setVisible(true);
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                shapeX -= 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_RIGHT:
                shapeX += 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_UP:
                shapeY -= 1;
                freezeShape = false;
                break;
            case KeyEvent.VK_DOWN:
                shapeY += 1;
                freezeShape = false;
                break;
        }
        // Keep shape within bounds
    //    if (shapeX < 0) shapeX = 0;
       // if (shapeX > panelWidth - shapeSize) shapeX = panelWidth - shapeSize;
        //  if (shapeY < 0) shapeY = 0;
       // if (shapeY > panelHeight - shapeSize) shapeY = panelHeight - shapeSize;
        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public int getScore() {
        return score;
    }
}
