import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Level2 extends JPanel implements ActionListener, KeyListener {
    // Game dimensions and settings
    int panelWidth = 450;
    int panelHeight = 580;
    int shapeSize = 55;
    int shapeX, shapeY;
    int slotY;

    // Slot positions for 5 shapes
    int circleSlotX = 100;
    int rectangleSlotX = 180;
    int triangleSlotX = 240;
    int rhombusSlotX = 290;
    int parallelogramSlotX = 360;

    // Game state variables
    int score = 0;
    int sorted = 0;
    int totalToWin = 2; // Increased for Level 2
    int timeLeft = 90; // More time for Level 2
    Timer count;
    int tolerance = 10; // Increased tolerance for easier matches
    int visualGuide = 10;

    // Images
    BufferedImage backgroundImage;
    BufferedImage leaf, tree, stone;
    BufferedImage circle,triangle, rectangle, rhombus, parallelogram;

    // Game state flags
    public boolean freezeShape = false;
    boolean gameStarted = false;
    boolean gameWin = false;
    boolean gameOver = false;
    boolean shapeProc = false;

    // Shape and scoring variables
    String currentShape;
    int circleSort = 0, rectangleSort = 0, triangleSort = 0, rhombusSort = 0, parallelogramSort = 0;
    int missedCircle = 0, missedrectangle = 0, missedTriangle = 0, missedRhombus = 0, missedParallelogram = 0;
    int fallingShape = 3; // Slightly slower for Level 2

    // Obstacle variables
    int leafX, leafY, treeX, treeY, stoneX, stoneY;
    int leafSize = 60, treeSize = 50, stoneSize = 60;
    int obstacleDown = 25;

    // Game arrays - Level 2 includes rhombus and parallelogram
    String[] shapes = {"rectangle", "Parallelogram", "Triangle", "Rhombus", "Circle"};
    String[] slotShape = {"Parallelogram", "Circle", "Triangle", "Rhombus", "rectangle"};
    int[] slotPos = {rectangleSlotX, circleSlotX, triangleSlotX, rhombusSlotX, parallelogramSlotX};
    int shapeIndex = 0;

    // UI Components
    public JButton restart;
    public JButton backToMenu;
    public JButton nextLevel;
    public Clip matchSound;
    public Timer timer;
    private Main parentFrame; // Changed from JFrame to Main for direct access to Main methods
    private GamePanel level1Panel;

    public Level2(Main parentFrame, GamePanel level1Panel) { // Changed parameter type
        this.parentFrame = parentFrame;
        this.level1Panel = level1Panel;
        setPreferredSize(new Dimension(1000, 700)); // Fixed size to match game window
        setBackground(Color.BLACK);
        setLayout(null);

        initializeButtons(); // Call initializeButtons here

        timer = new Timer(35, this); // Slightly faster timer
        addKeyListener(this);
        createShapeBufferedImages();
        loadBufferedImages();
        setFocusable(true);
    }

    private void initializeButtons() {
        restart = new JButton("Restart");
        restart.setBounds(panelWidth + 50, panelHeight / 2, 90, 50);
        restart.setForeground(Color.CYAN);
        restart.addActionListener(e -> restart());
        restart.setVisible(false);
        this.add(restart);

        backToMenu = new JButton("Main Menu");
        backToMenu.setBounds(panelWidth + 150, panelHeight / 2, 100, 50);
        backToMenu.setForeground(Color.ORANGE);
        backToMenu.addActionListener(e -> returnToMainMenu());
        backToMenu.setVisible(false);
        this.add(backToMenu);
        nextLevel = new JButton("Next Level");
        nextLevel.setBounds(panelWidth + 250, panelHeight / 2, 100, 50);
        nextLevel.setForeground(Color.CYAN);
        nextLevel.addActionListener(e -> startNextLevel());
        nextLevel.setVisible(false);
        this.add(nextLevel);
    }

    private void returnToMainMenu() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        // Dispose the current game window and show the main menu
        SwingUtilities.getWindowAncestor(this).dispose();
        parentFrame.refreshMainMenu(); // Refresh main menu
        parentFrame.setVisible(true);
    }  private void startNextLevel() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        // Clear buttons before starting next level
        removeAll();
        revalidate();
        repaint();
        parentFrame.startLevel(3); // Assuming Level 4 is the next level
    }

    public void createShapeBufferedImages() {
        // Create circle
        circle = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = circle.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.GREEN);
        g2d.fillOval(0, 0, shapeSize, shapeSize);
        g2d.setColor(Color.GREEN);
        g2d.drawOval(1, 1, shapeSize - 2, shapeSize - 2);
        g2d.dispose();

        // Create rectangle
        rectangle = new BufferedImage(shapeSize*2, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = rectangle.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.RED);
        g2d.fillRect(0, 0, shapeSize*2, shapeSize);
        g2d.setColor(Color.RED);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawRect(1, 1, (shapeSize - 2)*2, shapeSize - 2);
        g2d.dispose();

        // Create triangle
        triangle = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = triangle.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.ORANGE);
        int[] xp = {shapeSize / 2, 0, shapeSize};
        int[] yp = {0, shapeSize, shapeSize};
        g2d.fillPolygon(xp, yp, 3);
        g2d.setColor(Color.decode("#FF8C00"));
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(xp, yp, 3);
        g2d.dispose();

        // Create rhombus (diamond shape)
        rhombus = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = rhombus.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.MAGENTA);
        int[] rhombusX = {shapeSize / 2, shapeSize, shapeSize / 2, 0};
        int[] rhombusY = {0, shapeSize / 2, shapeSize, shapeSize / 2};
        g2d.fillPolygon(rhombusX, rhombusY, 4);
        g2d.setColor(Color.MAGENTA.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(rhombusX, rhombusY, 4);
        g2d.dispose();

        // Create parallelogram
        parallelogram = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = parallelogram.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.CYAN);
        int[] paraX = {10, shapeSize, shapeSize - 10, 0};
        int[] paraY = {0, 0, shapeSize, shapeSize};
        g2d.fillPolygon(paraX, paraY, 4);
        g2d.setColor(Color.CYAN.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawPolygon(paraX, paraY, 4);
        g2d.dispose();
    }

    private void loadBufferedImages() {
        try {
            leaf = ImageIO.read(getClass().getResource("/leaf.png"));
            tree = ImageIO.read(getClass().getResource("/tree.png"));
            stone = ImageIO.read(getClass().getResource("/stone.png"));
            backgroundImage = ImageIO.read(getClass().getResource("/lv2.png"));
        } catch (IOException e) {
            e.printStackTrace();
            createFallbackImages();
        }
    }

    private void createFallbackImages() {
        // Create fallback background
        backgroundImage = new BufferedImage(panelWidth, panelHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = backgroundImage.createGraphics();
        GradientPaint gradient = new GradientPaint(0, 0, new Color(25, 25, 112), panelWidth, panelHeight, new Color(72, 61, 139));
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, panelWidth, panelHeight);
        g2d.dispose();

        // Create simple obstacle images
        leaf = createSimpleObstacle(leafSize, Color.GREEN);
        tree = createSimpleObstacle(treeSize, new Color(139, 69, 19));
        stone = createSimpleObstacle(stoneSize, Color.GRAY);
    }

    private BufferedImage createSimpleObstacle(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(color);
        g2d.fillOval(0, 0, size, size);
        g2d.setColor(color.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawOval(1, 1, size - 2, size - 2);
        g2d.dispose();
        return img;
    }

    public void startGame() {
        gameStarted = true;
        gameOver = false;
        gameWin = false;
        score = 0;
        sorted = 0;
        timeLeft = 90;

        // Reset all counters
        circleSort = rectangleSort = triangleSort = rhombusSort = parallelogramSort = 0;
        missedCircle = missedrectangle = missedTriangle = missedRhombus = missedParallelogram = 0;
        shapeIndex = 0;

        slotY = panelHeight - 30;
        spawnNewShape();
        spawnObstacles();

        if (count != null) count.stop();
        count = new Timer(1000, e -> {
            if (!gameOver && !gameWin) {
                timeLeft--;
                if (timeLeft <= 0) {
                    gameOver = true;
                    count.stop();
                    timer.stop();
                    repaint();
                }
            }
        });
        count.start();

        timer.start();
        requestFocusInWindow();
        repaint();
    }

    public void restart() {
        startGame();
    }

    public void spawnObstacles() {
        leafX = panelWidth / 2 - 30;
        leafY = 75;
        treeX = panelWidth / 2 + 70;
        treeY = 100;
        stoneX = panelWidth / 2;
        stoneY = 350;
    }

    public void shuffle() {
        String first = slotShape[0];
        for (int i = 0; i < slotShape.length - 1; i++) {
            slotShape[i] = slotShape[i + 1];
        }
        slotShape[slotShape.length - 1] = first;

        int firstPos = slotPos[0];
        for (int i = 0; i < slotPos.length - 1; i++) {
            slotPos[i] = slotPos[i + 1];
        }
        slotPos[slotPos.length - 1] = firstPos;
    }

    public void spawnNewShape() {
        currentShape = shapes[shapeIndex];
        shapeX = panelWidth / 2;
        shapeY = 0;
        shapeIndex++;
        if (shapeIndex >= shapes.length) {
            shapeIndex = 0;
        }
        shuffle();
        freezeShape = false;
        shapeProc = false;
    }

    public void moveObstaclesDown() {
        leafY += obstacleDown;
        treeY += obstacleDown;
        stoneY += obstacleDown;

        if (leafY > panelHeight - 100) {
            leafY = 50 + (int) (Math.random() * 50);
            leafX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (treeY > panelHeight - 100) {
            treeY = 50 + (int) (Math.random() * 50);
            treeX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (stoneY > panelHeight - 100) {
            stoneY = 50 + (int) (Math.random() * 50);
            stoneX = 50 + (int) (Math.random() * (panelWidth - 100));
        }

        // Randomly shuffle obstacle positions
        if (Math.random() > 0.5) {
            int tempX = leafX;
            leafX = treeX;
            treeX = tempX;
        }
        if (Math.random() > 0.5) {
            int tempX = stoneX;
            stoneX = leafX;
            leafX = tempX;
        }
    }

    private BufferedImage getCurrentShapeImage() {
        switch (currentShape) {
            case "Circle": return circle;
            case "rectangle": return rectangle;
            case "Triangle": return triangle;
            case "Rhombus": return rhombus;
            case "Parallelogram": return parallelogram;
            default: return null;
        }
    }

    private boolean checkCollision(BufferedImage obstacle, int obstacleX, int obstacleY, int obstacleWidth, int obstacleHeight, int currentShapeWidth) {
        // Simple bounding box collision for performance
        int shapeLeft = shapeX;
        int shapeRight = shapeX + currentShapeWidth; // Use currentShapeWidth
        int shapeTop = shapeY;
        int shapeBottom = shapeY + shapeSize; // Height is always shapeSize
        int obstacleLeft = obstacleX;
        int obstacleRight = obstacleX + obstacleWidth;
        int obstacleTop = obstacleY;
        int obstacleBottom = obstacleY + obstacleHeight;

        return !(shapeRight < obstacleLeft || shapeLeft > obstacleRight ||
                shapeBottom < obstacleTop || shapeTop > obstacleBottom);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }

        int currentShapeWidth = shapeSize;
        if (currentShape != null && currentShape.equals("rectangle")) {
            currentShapeWidth = shapeSize * 2;
        }

        if (!freezeShape) {
            shapeY += fallingShape;

            // Check collision with obstacles
            if (checkCollision(leaf, leafX, leafY, leafSize, leafSize, currentShapeWidth) ||
                    checkCollision(tree, treeX, treeY, treeSize, treeSize, currentShapeWidth) ||
                    checkCollision(stone, stoneX, stoneY, stoneSize, stoneSize, currentShapeWidth)) {
                freezeShape = true;
            }
        }

        if (shapeY + shapeSize >= slotY && !shapeProc) {
            if (isShapeInCorrectSlot()) {
                int pointsEarn = getPointsEarned();
                score += pointsEarn;
                sorted++;
                if (currentShape.equals("Circle")) {
                    circleSort++;
                } else if (currentShape.equals("rectangle")) {
                    rectangleSort++;
                } else if (currentShape.equals("Triangle")) {
                    triangleSort++;
                }else if (currentShape.equals("Parallelogram")) {
                    parallelogramSort++;
                }else if (currentShape.equals("Rhombus")) {
                    rhombusSort++;
                }
                shapeProc = true;
                shuffle();
                moveObstaclesDown();
                if (sorted >= totalToWin) {
                    gameWin = true;
                    timer.stop();
                    // Notify parent frame of level completion
                    SwingUtilities.invokeLater(() -> {
                        parentFrame.unlockLevel(3, score);
                    });
                    repaint();
                    return;
                }
                spawnNewShape();
            }
        }
        if (shapeY > panelHeight + shapeSize && !shapeProc) {
            score -= 5;
            moveObstaclesDown();
            if (currentShape.equals("Circle")) {
                missedCircle++;
            } else if (currentShape.equals("rectangle")) {
                missedrectangle++;
            } else if (currentShape.equals("Triangle")) {
                missedTriangle++;
            } else if (currentShape.equals("Parallelogram")) {
                missedParallelogram++;
            } else if (currentShape.equals("Rhombus")) {
                missedRhombus++;
            }
            shapeProc = true;
            spawnNewShape();
        }
        repaint();
    }

    private int getPointsEarned() {
        int basePoints;
        switch (currentShape) {
            case "Circle": basePoints = 50; break;
            case "rectangle": basePoints = 40; break;
            case "Triangle": basePoints = 30; break;
            case "Rhombus": basePoints = 60; break; // Higher points for new shapes
            case "Parallelogram": basePoints = 70; break;
            default: basePoints = 10;
        }
        // Bonus points for time remaining
        int timeBonus = Math.max(0, timeLeft / 15);
        return basePoints + timeBonus;
    }

    private boolean isShapeInCorrectSlot() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return isShapePerfectlyAligned(slotPos[i]);
            }
        }
        return false;
    }

    private boolean isShapePerfectlyAligned(int targetSlotX) {
        boolean xMatch = Math.abs(shapeX - targetSlotX) <= tolerance;
        boolean yMatch = Math.abs(shapeY - slotY) <= tolerance;
        return xMatch && yMatch;
    }

    private int getTargetSlotX() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return slotPos[i];
            }
        }
        return -1;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw background
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }

        if (gameStarted && !gameOver && !gameWin) {
            // Draw current falling shape
            BufferedImage currentShapeImg = getCurrentShapeImage();
            if (currentShapeImg != null) {
                // Use the actual dimensions of the buffered image for drawing
                g.drawImage(currentShapeImg, shapeX, shapeY, currentShapeImg.getWidth(), currentShapeImg.getHeight(), this);
            }

            // Draw slots
            drawSlots(g);

            // Draw obstacles
            if (leaf != null) g.drawImage(leaf, leafX, leafY, leafSize, leafSize, this);
            if (tree != null) g.drawImage(tree, treeX, treeY, treeSize, treeSize, this);
            if (stone != null) g.drawImage(stone, stoneX, stoneY, stoneSize, stoneSize, this);

            // Draw visual guides
            drawVisualGuides(g);
        }

        // Draw game stats
        drawGameStats(g);

        // Draw game over/win screens
        if (gameOver) {
            drawGameOverScreen(g);
        } else if (gameWin) {
            drawWinScreen(g);
        }
    }

    private void drawSlots(Graphics g) {
        for (int i = 0; i < slotShape.length; i++) {
            switch (slotShape[i]) {
                case "Circle":
                    g.setColor(Color.MAGENTA);
                    g.fillOval(slotPos[i], slotY, shapeSize, shapeSize);
                    g.setColor(Color.BLACK);
                    g.drawOval(slotPos[i], slotY, shapeSize, shapeSize);
                    if (currentShape.equals("Circle")) {
                        g.setColor(Color.ORANGE);
                        g.drawOval(slotPos[i] - tolerance, slotY - tolerance,
                                shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                    }
                    break;
                case "rectangle":
                    g.setColor(Color.PINK);
                    g.fillRect(slotPos[i], slotY, shapeSize*2, shapeSize);
                    g.setColor(Color.BLACK);
                    g.drawRect(slotPos[i], slotY, shapeSize*2, shapeSize);
                    if (currentShape.equals("rectangle")) {
                        g.setColor(Color.ORANGE);
                        g.drawRect(slotPos[i] - tolerance, slotY - tolerance,
                                (shapeSize + (tolerance * 2))*2, shapeSize + (tolerance * 2));
                    }
                    break;
                case "Triangle":
                    g.setColor(Color.PINK);
                    int[] x = {slotPos[i] + shapeSize / 2, slotPos[i], slotPos[i] + shapeSize};
                    int[] y = {slotY, slotY + shapeSize, slotY + shapeSize};
                    g.fillPolygon(x, y, 3);
                    g.setColor(Color.BLACK); // Added black border for triangle slot
                    g.drawPolygon(x, y, 3);
                    if (currentShape.equals("Triangle")) {
                        g.setColor(Color.ORANGE);
                        g.drawPolygon(x, y, 3);
                    }
                    break;
                case "Rhombus":
                    g.setColor(Color.LIGHT_GRAY);
                    int[] rhombusX = {slotPos[i] + shapeSize / 2, slotPos[i] + shapeSize, slotPos[i] + shapeSize / 2, slotPos[i]};
                    int[] rhombusY = {slotY, slotY + shapeSize / 2, slotY + shapeSize, slotY + shapeSize / 2};
                    g.fillPolygon(rhombusX, rhombusY, 4);
                    g.setColor(Color.BLACK); // Added black border for rhombus slot
                    g.drawPolygon(rhombusX, rhombusY, 4);
                    if (currentShape.equals("Rhombus")) {
                        g.setColor(Color.ORANGE);
                        g.drawPolygon(rhombusX, rhombusY, 4);
                    }
                    break;
                case "Parallelogram":
                    g.setColor(Color.LIGHT_GRAY);
                    int[] paraX = {slotPos[i] + 10, slotPos[i] + shapeSize, slotPos[i] + shapeSize - 10, slotPos[i]};
                    int[] paraY = {slotY, slotY, slotY + shapeSize, slotY + shapeSize};
                    g.fillPolygon(paraX, paraY, 4);
                    g.setColor(Color.BLACK); // Added black border for parallelogram slot
                    g.drawPolygon(paraX, paraY, 4);
                    if (currentShape.equals("Parallelogram")) {
                        g.setColor(Color.ORANGE);
                        g.drawPolygon(paraX, paraY, 4);
                    }
                    break;
            }
        }
    }

    private void drawVisualGuides(Graphics g) {
        int targetSlotX = getTargetSlotX();
        if (targetSlotX != -1) {
            g.setColor(new Color(255, 255, 0, 50));

            int currentShapeWidth = shapeSize;
            if (currentShape != null && currentShape.equals("rectangle")) {
                currentShapeWidth = shapeSize * 2;
            }

            // Vertical guide
            if (Math.abs(shapeX - targetSlotX) <= visualGuide) {
                g.fillRect(targetSlotX, 0, currentShapeWidth, panelHeight); // Use currentShapeWidth
                g.drawString(Math.abs(shapeX - targetSlotX) + "px", targetSlotX + currentShapeWidth + 5, shapeY + shapeSize / 2);
            }

            // Horizontal guide
            if (Math.abs(shapeY - slotY) <= visualGuide) {
                g.fillRect(0, slotY, panelWidth, shapeSize);
                g.drawString(Math.abs(shapeY - slotY) + "px", shapeX + currentShapeWidth + 5, shapeY + shapeSize / 2); // Adjust string position
            }

            // Perfect alignment indicator
            if (Math.abs(shapeX - targetSlotX) <= tolerance && Math.abs(shapeY - slotY) <= tolerance) {
                g.setColor(new Color(0, 255, 0, 100));
                g.fillRect(targetSlotX - 2, slotY - 2, currentShapeWidth + 4, shapeSize + 4); // Use currentShapeWidth
            }
        }
    }

    private void drawGameStats(Graphics g) {
        if (gameStarted) {
            // Stats panel background
            g.setColor(new Color(0, 0, 0, 180));
            g.fillRoundRect(700, 50, 200, 300, 20, 20);
            // Stats text
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 16));
            int tX = 715;
            int tY = 75;
            int lineHeight = 20;
            g.setColor(Color.ORANGE);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("LEVEL 2", tX, tY);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
            g.drawString("Score: " + score, tX, tY +lineHeight);
            g.drawString("Sorted: " + sorted + "/" + totalToWin, tX, tY +lineHeight*2);
            g.drawString("Time: " + timeLeft + "s", tX, tY +lineHeight*3);
            g.drawString("⚪✓ " + circleSort + " ❌" + missedCircle, tX, tY +lineHeight * 5);
            g.drawString("△✓ " + triangleSort + " ❌" + missedTriangle, tX, tY + lineHeight * 6);
            g.drawString("▭✓ " + rectangleSort + " ❌" + missedrectangle, tX, tY + lineHeight * 7);
            g.drawString("◇✓ " + rhombusSort + " ❌" + missedRhombus, tX, tY + lineHeight * 8);
            g.drawString("▱✓ " +parallelogramSort + " ❌" + missedParallelogram, tX, tY + lineHeight* 9);
        }
    }

    private void drawGameOverScreen(Graphics g) {
        g.setColor(new Color(0, 0, 0, 200));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        FontMetrics fm = g.getFontMetrics();
        String gameOverText = "GAME OVER";
        int x = (panelWidth - fm.stringWidth(gameOverText)) / 2;
        g.drawString(gameOverText, x, panelHeight / 2 - 50);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        fm = g.getFontMetrics();
        String scoreText = "Final Score: " + score;
        x = (panelWidth - fm.stringWidth(scoreText)) / 2;
        g.drawString(scoreText, x, panelHeight / 2);
        // Remove existing buttons before adding new ones to prevent duplicates
        removeAll();
        revalidate();
        repaint();
        restart.setVisible(true);
        // Add a "Back to Main Menu" button for game over
        JButton backToMenuButton = new JButton("Main Menu");
        backToMenuButton.setBounds(x, panelHeight / 2 + 110, 200, 50);
        backToMenuButton.setForeground(Color.ORANGE);
        backToMenuButton.setBackground(new Color(100, 100, 100));
        backToMenuButton.setFont(new Font("Arial", Font.BOLD, 16));
        backToMenuButton.addActionListener(e -> {
            System.out.println("GamePanel (Level 2): Game Over. Sending score to Main: " + score);
            parentFrame.addToTotalScore(score); // Add current level score to total
            // Dispose the current game window and show the main menu
            SwingUtilities.getWindowAncestor(this).dispose();
            parentFrame.refreshMainMenu(); // Refresh main menu
            parentFrame.setVisible(true);
        });
        this.add(backToMenuButton);
        backToMenuButton.setVisible(true);
    }

    private void drawWinScreen(Graphics g) {
        g.setColor(new Color(0, 100, 0, 200));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.YELLOW);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        FontMetrics fm = g.getFontMetrics();
        String winText = "LEVEL 2 COMPLETE!";
        int x = (panelWidth - fm.stringWidth(winText)) / 2;
        g.drawString(winText, x, panelHeight / 2 - 50);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        fm = g.getFontMetrics();
        String scoreText = "Score: " + score;
        x = (panelWidth - fm.stringWidth(scoreText)) / 2;
        g.drawString(scoreText, x, panelHeight / 2);
        // Remove existing buttons before adding new ones to prevent duplicates
        removeAll();
        revalidate();
        repaint();
        // Hide restart and backToMenu buttons from win screen
        restart.setVisible(true);
        // Add a "Next Level" button
//        JButton nextLevelButton = new JButton("Next Level (Level 3)");
//        nextLevelButton.setBounds(x, panelHeight / 2 + 50, 200, 50);
//        nextLevelButton.setForeground(Color.BLUE);
//        nextLevelButton.setBackground(new Color(156, 39, 176)); // Purple color for Level 3
//        nextLevelButton.setFont(new Font("Arial", Font.BOLD, 16));
//        nextLevelButton.addActionListener(e -> {
//            System.out.println("GamePanel (Level 2): Level Win. Sending score to Main: " + score);
//            parentFrame.addToTotalScore(score); // Add current level score to total
//            parentFrame.unlockLevel(3, score); // Unlock Level 3
//            // Dispose the current game window and show the main menu
//            SwingUtilities.getWindowAncestor(this).dispose();
//            parentFrame.refreshMainMenu(); // Refresh main menu
//            parentFrame.setVisible(true);
//        });
       // this.add(nextLevelButton);
      //  nextLevelButton.setVisible(true);
        // Add a "Back to Main Menu" button
 add(nextLevel);
 nextLevel.setVisible(true);
//        JButton backToMenuButton = new JButton("Main Menu");
//        backToMenuButton.setBounds(x, panelHeight / 2 + 110, 200, 50);
//        backToMenuButton.setForeground(Color.ORANGE);
//        backToMenuButton.setBackground(new Color(100, 100, 100));
//        backToMenuButton.setFont(new Font("Arial", Font.BOLD, 16));
//        backToMenuButton.addActionListener(e -> {
//            parentFrame.addToTotalScore(score); // Add current level score to total
//            // Dispose the current game window and show the main menu
//            SwingUtilities.getWindowAncestor(this).dispose();
//            parentFrame.refreshMainMenu(); // Refresh main menu
//            parentFrame.setVisible(true);
//        });
        add(backToMenu);
        backToMenu.setVisible(true);
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }

        int currentShapeWidth = shapeSize;
        if (currentShape != null && currentShape.equals("rectangle")) {
            currentShapeWidth = shapeSize * 2;
        }

        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                shapeX -= 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_RIGHT:
                shapeX += 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_UP:
                shapeX -= 1;
                freezeShape = false;
                break;
            case KeyEvent.VK_DOWN:
                shapeX += 1;
                freezeShape = false;
                break;
        }

        // Keep shape within bounds
//        if (shapeX < 0) shapeX = 0;
//        if (shapeX > panelWidth - currentShapeWidth) shapeX = panelWidth - currentShapeWidth; // Use currentShapeWidth

        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    public int getScore() {
        return score;
    }
}