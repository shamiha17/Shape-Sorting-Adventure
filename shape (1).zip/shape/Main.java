
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.imageio.ImageIO;
import java.io.*;
import java.util.Objects;
public class Main extends JFrame {
    public int totalScore = 0;
    private GamePanel level1Panel;
    public Level2 level2Panel;
    public Level3 level3Panel;
    public Level4 level4Panel;
    public Level5 level5Panel;
    public BufferedImage backgroundImage;
    private JButton level2Button;
    private JButton level3Button;
    private JButton level4Button;
    private JButton level5Button;
    private boolean isLevel2Unlocked = false;
    private boolean isLevel3Unlocked = false;
    private boolean isLevel4Unlocked = false;
    private boolean isLevel5Unlocked = false;

    public Main() {

        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);


        try {
            backgroundImage = ImageIO.read(getClass().getResource("/gt.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println(" Image not found!");

        }

        createMainMenu(); // Call method to create the main menu content
        setVisible(true);
    }

    private void createMainMenu() {
        getContentPane().removeAll();
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
      panel.add(Box.createVerticalStrut(80));

        String[] levels = {
                "Level 1 ",
                "Level 2 ",
                "Level 3 ",
                "Level 4 ",
                "Level 5 "
        };
        Color[] colors = {
                new Color(5, 65, 70, 114),
                new Color(5, 70, 55, 100),
                new Color(5, 9, 70, 100),
                new Color(1, 9, 19, 100),
                new Color(0, 44, 60, 100)
        };

        for (int i = 0; i < 5; i++) {
            JButton button = new JButton(levels[i]);
            button.setFont(new Font("Arial", Font.BOLD, 12));
            button.setBackground(colors[i]);
            button.setForeground(Color.WHITE);
            button.setMaximumSize(new Dimension(400, 45));
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setFocusPainted(false);
            final int levelNum = i + 1;final Color originalColor = colors[i];
            if (levelNum == 2) {
                level2Button = button;
            } else if (levelNum == 3) {
                level3Button = button;
            }else if (levelNum == 4) {
                level4Button = button;
            }else if (levelNum == 5) {
                level5Button = button;
            }


            if (levelNum > 1) { // Levels 2, 3, 4, 5 are initially disabled
                button.setEnabled(false);
            }
            if (levelNum == 1) {
                button.setEnabled(true);
            }

            if (levelNum == 2 && isLevel2Unlocked) {
                button.setEnabled(true);
            }
            if (levelNum == 3 && isLevel3Unlocked) {
                button.setEnabled(true);
            } if (levelNum == 4 && isLevel4Unlocked) {
                button.setEnabled(true);
            } if (levelNum == 5 && isLevel5Unlocked) {
                button.setEnabled(true);
            }

            button.addActionListener(e -> startLevel(levelNum));

            panel.add(button);panel.add(Box.createVerticalStrut(8));
        }

        setContentPane(panel);
        revalidate(); // Revalidate the content pane to apply changes
        repaint();    // Repaint to show the updated UI
    }

    public void startLevel(int levelNum) {

        setVisible(false);
        JPanel gamePanel = null;
        String title = "";

        switch (levelNum) {
            case 1:
                if (level1Panel == null) {
                    level1Panel = new GamePanel(this);
                }
                gamePanel = level1Panel;
                title = "Level 1 ";
                SwingUtilities.invokeLater(() -> {
                    level1Panel.startGame();
                });
                break;

            case 2:
                if (level2Panel == null) {
                    level2Panel = new Level2(this, getLevel1Panel());
                }
                gamePanel = level2Panel;
                title = "Level 2 ";
                SwingUtilities.invokeLater(() -> {
                    level2Panel.startGame();
                });
                break;

            case 3:
                if (level3Panel == null) {
                    level3Panel = new Level3(this, getLevel1Panel()); // Corrected class name
                }
                gamePanel = level3Panel;
                title = "Level 3";
                SwingUtilities.invokeLater(() -> {
                    level3Panel.startGame();
                });
                break;

            case 4:
                // Level 4 not implemented yet
                if(level4Panel==null)
                {level4Panel=new Level4(this,getLevel1Panel());}
                gamePanel=level4Panel;
                title="Level 4";
                SwingUtilities.invokeLater(()->
            {level4Panel.startGame();});break;
            case 5:
                if(level5Panel==null)
                {level5Panel=new Level5(this, getLevel1Panel());}
                gamePanel=level5Panel;
                title="Level 5";
                SwingUtilities.invokeLater(()->
                {level5Panel.startGame();});break;


            default:
                if (level1Panel == null) {
                    level1Panel = new GamePanel(this);
                }
                gamePanel = level1Panel;
                title = "Level 1 ";
                SwingUtilities.invokeLater(() -> level1Panel.startGame());
        }

        if (gamePanel != null) {
            // Create game window
            JFrame gameWindow = new JFrame(title);
            gameWindow.add(gamePanel);
            gameWindow.setSize(950, 800); // Consistent size
            gameWindow.setLocationRelativeTo(this);
            gameWindow.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            gameWindow.setResizable(true);

            // Add window icon if available
            try {
                BufferedImage icon = ImageIO.read(Objects.requireNonNull(getClass().getResource("/gt.jpg")));
                gameWindow.setIconImage(icon);
            } catch (Exception e) {
                // Icon not found, continue without it
            }

            // Return to menu when closed
            gameWindow.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    System.out.println("Main: Window closing event for level " + levelNum);
                    gameWindow.dispose();
                    refreshMainMenu(); // Refresh main menu when returning
                    setVisible(true);
                    // Update total score when returning to menu if not already updated by win screen
                    // This ensures score is updated even if user closes window mid-game
                    if (levelNum == 1 && level1Panel != null) {
                        System.out.println("Main: Retrieving score from Level 1 panel: " + level1Panel.getScore());
                        addToTotalScore(level1Panel.getScore());
                    } else if (levelNum == 2 && level2Panel != null) {
                        System.out.println("Main: Retrieving score from Level 2 panel: " + level2Panel.getScore());
                        addToTotalScore(level2Panel.getScore());
                    }else if (levelNum ==3 && level3Panel != null) {
                        System.out.println("Main: Retrieving score from Level 3 panel: " + level3Panel.getScore());
                        addToTotalScore(level3Panel.getScore());
                    }else if (levelNum == 4 && level4Panel != null) {
                        System.out.println("Main: Retrieving score from Level 4 panel: " + level4Panel.getScore());
                        addToTotalScore(level4Panel.getScore());
                    }else if (levelNum == 5 && level5Panel != null) {
                        System.out.println("Main: Retrieving score from Level 5 panel: " + level5Panel.getScore());
                        addToTotalScore(level5Panel.getScore());
                  }
//                    else if (level5Panel != null) { // Check level3Panel directly
//                        System.out.println("Main: Retrieving score from Level 5 panel: " + level5Panel.getScore());
//                        addToTotalScore(level5Panel.getScore());
//                    }
                }
            });

            gameWindow.setVisible(true);

            // Request focus for the game panel so keyboard input works
            JPanel finalGamePanel = gamePanel;
            SwingUtilities.invokeLater(() -> {
                finalGamePanel.requestFocusInWindow();
            });
        }
    }

    // Helper method to get Level 1 panel for other levels that might need it
    private GamePanel getLevel1Panel() {
        if (level1Panel == null) {
            level1Panel = new GamePanel(this);
        }
        return level1Panel;
    }

    public void updateScore(int newScore) {
        if (newScore > 0) {
            totalScore = newScore;

        }
    }
    public void returnToMenu() {
        refreshMainMenu();
        setVisible(true);
    }
    public int getTotalScore() {
        return totalScore;
    }
    public void addToTotalScore(int points) {
        totalScore += points;
    }
    public void unlockLevel(int levelNum, int score) {
        System.out.println("unlockLevel called for level: " + levelNum + ", current score: " + score);
        if (levelNum == 2) {
            isLevel2Unlocked = true;
            if (level2Button != null) {
                level2Button.setEnabled(true);
                System.out.println("Level 2 button enabled: " + level2Button.isEnabled());
            } else {
                System.out.println("Level 2 button is null when trying to enable.");
            }
        } else if (levelNum == 3) {
            isLevel3Unlocked = true;
            if (level3Button != null) {
                level3Button.setEnabled(true);
                System.out.println("Level 3 button enabled: " + level3Button.isEnabled());
            }   else {
                System.out.println("Level 3 button is null when trying to enable.");
            }
        }
            else if (levelNum == 4) {
            isLevel4Unlocked = true;
            if (level4Button != null) {
                level4Button.setEnabled(true);
                System.out.println("Level 4 button enabled: " + level4Button.isEnabled());
            }
            else {
                System.out.println("Level 4 button is null when trying to enable.");
            }
        }else if (levelNum == 5) {
            isLevel5Unlocked = true;
            if (level5Button != null) {
                level5Button.setEnabled(true);
                System.out.println("Level 5 button enabled: " + level5Button.isEnabled());
            }
            else {
                System.out.println("Level 5 button is null when trying to enable.");
            }
        }
        refreshMainMenu();
    }
    public void refreshMainMenu() {
        createMainMenu();
        this.revalidate();
        this.repaint();
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.setProperty("sun.java2d.uiScale", "1.0");


            new Main();
        });
    }
}
