import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Level4 extends JPanel implements ActionListener, KeyListener {
    // Game dimensions and settings
    int panelWidth = 450;
    int panelHeight = 580;
    int shapeSize = 80;
    int shapeX, shapeY;
    int slotY;
    // Slot positions for Level 4
    int diamondSlotX = 90;
    int moonSlotX = 180;
    int cloudSlotX = 270;

    int squareSlotX=360;
    // Game state variables
    int score = 0;
    int sorted = 0;
    int totalToWin = 3; // Changed from 1 to 10 for actual gameplay
    int timeLeft = 90;
    Timer count;
    int tolerance = 10;
    int visualGuide = 10;

    // Images
    BufferedImage backgroundImage;
    BufferedImage tree, stone, leaf; // Obstacles for Level 4
    BufferedImage diamond, moon, cloud,square; // New shapes for Level 4

    // Game state flags
    public boolean freezeShape = false;
    boolean gameStarted = false;
    boolean gameWin = false;
    boolean gameOver = false;
    boolean shapeProc = false;

    // Shape and scoring variables
    String currentShape;
    int diamondSort = 0, moonSort = 0, cloudSort = 0 ,squareSort = 0;
    int missedDiamond = 0, missedMoon = 0 , missedSquare = 0, missedCloud = 0; // Corrected casing

    int fallingShape =8;

    // Obstacle variables
    int treeX, treeY, stoneX, stoneY, leafX, leafY;
    int treeSize = 50, stoneSize = 60, leafSize = 55;
    int obstacleDown = 15;

    // Game arrays - Level 4 introduces new shapes
    String[] shapes = {"Diamond", "Moon", "Cloud","Square"}; // Corrected casing
    String[] slotShape = {"Moon", "Diamond", "Cloud","Square"}; // Corrected casing
    int[] slotPos = {diamondSlotX, moonSlotX, cloudSlotX,squareSlotX};
    int shapeIndex = 0;

    // UI Components
    public JButton restart;
    public JButton backToMenu;
    public JButton nextLevel; // New button for next level
    public Clip matchSound;
    public Timer timer;

    private Main parentFrame;
    private GamePanel level1Panel;

    public Level4(Main parentFrame, GamePanel level1Panel) {
        this.parentFrame = parentFrame;
        this.level1Panel = level1Panel;
        setPreferredSize(new Dimension(1000, 700));
        setBackground(Color.BLACK);
        setLayout(null);
        initializeButtons();
        timer = new Timer(25, this);
        addKeyListener(this);
        createShapeBufferedImages();
        loadBufferedImages();
        setFocusable(true);
    }

    private void initializeButtons() {
        restart = new JButton("Restart");
        restart.setBounds(panelWidth + 50, panelHeight / 2, 90, 50);
        restart.setForeground(Color.CYAN);
        restart.addActionListener(e -> restart());
        restart.setVisible(false);
        this.add(restart);

        backToMenu = new JButton("Main Menu");
        backToMenu.setBounds(panelWidth + 150, panelHeight / 2, 100, 50);
        backToMenu.setForeground(Color.ORANGE);
        backToMenu.addActionListener(e -> returnToMainMenu());
        backToMenu.setVisible(false);
        this.add(backToMenu);

        nextLevel = new JButton("Next Level");
        nextLevel.setBounds(panelWidth + 250, panelHeight / 2, 100, 50);
        nextLevel.setForeground(Color.GREEN);
        nextLevel.addActionListener(e -> startNextLevel());
        nextLevel.setVisible(false);
        this.add(nextLevel);
    }

    private void returnToMainMenu() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        parentFrame.addToTotalScore(score); // Add score to total before returning
        parentFrame.returnToMenu(); // Call the method in Main to show the main menu
    }

    private void startNextLevel() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        // Clear buttons before starting next level
        removeAll();
        revalidate();
        repaint();
        parentFrame.startLevel(5); // Assuming Level 5 is the next level
    }

    public void createShapeBufferedImages() {

        square = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D  g2d = square.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.RED);
        g2d.fillRect(0, 0, shapeSize, shapeSize);
        g2d.dispose();
    }

    private void loadBufferedImages() {
        try {
            leaf = ImageIO.read(getClass().getResource("/leaf.png"));
            tree = ImageIO.read(getClass().getResource("/tree.png"));
            stone = ImageIO.read(getClass().getResource("/stone.png"));
            diamond = ImageIO.read(getClass().getResource("/dia.png"));
            moon= ImageIO.read(getClass().getResource("/moon.png"));
            cloud= ImageIO.read(getClass().getResource("/cloud.png")); // Load diamond image
            backgroundImage = ImageIO.read(getClass().getResource("/lv4.jpg")); // New background for Level 4
        } catch (IOException e) {
            e.printStackTrace();
            createFallbackImages();
        }
    }

    private void createFallbackImages() {
        // Create fallback background with space theme
        backgroundImage = new BufferedImage(panelWidth, panelHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = backgroundImage.createGraphics();
        GradientPaint gradient = new GradientPaint(0, 0, new Color(10, 10, 30), panelWidth, panelHeight, new Color(50, 0, 80));
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, panelWidth, panelHeight);
        g2d.setColor(Color.WHITE);
        for (int i = 0; i < 70; i++) { // More diamonds
            int x = (int) (Math.random() * panelWidth);
            int y = (int) (Math.random() * panelHeight);
            g2d.fillOval(x, y, 2, 2);
        }
        g2d.dispose();

        // Create simple obstacle images
        tree = createSimpleObstacle(treeSize, Color.ORANGE);
        stone = createSimpleObstacle(stoneSize, new Color(100, 100, 100));
        leaf = createSimpleObstacle(leafSize, new Color(150, 50, 200));


    }

    private BufferedImage createSimpleObstacle(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(color);
        g2d.fillOval(0, 0, size, size);
        g2d.setColor(color.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawOval(1, 1, size - 2, size - 2);
        g2d.dispose();
        return img;
    }

    public void startGame() {
        gameStarted = true;
        gameOver = false;
        gameWin = false;
        score = 0;
        sorted = 0;
        timeLeft = 90;
        diamondSort = moonSort = cloudSort = 0;
        missedDiamond = missedMoon = missedCloud = 0; // Corrected casing
        shapeIndex = 0;
        slotY = panelHeight - 30;
        spawnNewShape();
        spawnObstacles();
        if (count != null) count.stop();
        count = new Timer(1000, e -> {
            if (!gameOver && !gameWin) {
                timeLeft--;
                if (timeLeft <= 0) {
                    gameOver = true;
                    count.stop();
                    timer.stop();
                    repaint();
                }
            }
        });
        count.start();
        timer.start();
        requestFocusInWindow();
        repaint();
    }

    public void restart() {
        startGame();
    }

    public void spawnObstacles() {
        treeX = panelWidth / 2 - 50;
        treeY = 100;
        stoneX = panelWidth / 2 + 50;
        stoneY = 200;
        leafX = panelWidth / 2;
        leafY = 300;
    }

    public void shuffle() {
        java.util.List<String> shapeList = new ArrayList<>(Arrays.asList(slotShape));
        java.util.List<Integer> posList = new ArrayList<>();
        for (int pos : slotPos) {
            posList.add(pos);
        }
        Collections.shuffle(shapeList);
        Collections.shuffle(posList);
        for (int i = 0; i < slotShape.length; i++) {
            slotShape[i] = shapeList.get(i);
            slotPos[i] = posList.get(i);
        }
    }

    public void spawnNewShape() {
        currentShape = shapes[shapeIndex];
        shapeX = panelWidth / 2;
        shapeY = 0;
        shapeIndex++;
        if (shapeIndex >= shapes.length) {
            shapeIndex = 0;
        }
        shuffle();
        freezeShape = false;
        shapeProc = false;
    }

    public void moveObstaclesDown() {
        treeY += obstacleDown;
        stoneY += obstacleDown;
        leafY += obstacleDown;
        if (treeY > panelHeight - 100) {
            treeY = 50 + (int) (Math.random() * 50);
            treeX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (stoneY > panelHeight - 100) {
            stoneY = 50 + (int) (Math.random() * 50);
            stoneX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (leafY > panelHeight - 100) {
            leafY = 50 + (int) (Math.random() * 50);
            leafX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        // Randomly shuffle obstacle positions
        if (Math.random() > 0.5) {
            int tempX = treeX;
            treeX = stoneX;
            stoneX = tempX;
        }
        if (Math.random() > 0.5) {
            int tempX = leafX;
            leafX = treeX;
            treeX = tempX;
        }
    }

    private BufferedImage getCurrentShapeImage() {
        switch (currentShape) {
            case "Diamond": return diamond; // Corrected casing
            case "Moon": return moon;
            case "Cloud": return cloud;
            case "Square": return square;// Corrected casing
            default: return null;
        }
    }

    private boolean checkCollision(BufferedImage obstacle, int obstacleX, int obstacleY, int obstacleWidth, int obstacleHeight) {
        int shapeLeft = shapeX;
        int shapeRight = shapeX + shapeSize;
        int shapeTop = shapeY;
        int shapeBottom = shapeY + shapeSize;
        int obstacleLeft = obstacleX;
        int obstacleRight = obstacleX + obstacleWidth;
        int obstacleTop = obstacleY;
        int obstacleBottom = obstacleY + obstacleHeight;
        return !(shapeRight < obstacleLeft || shapeLeft > obstacleRight ||
                shapeBottom < obstacleTop || shapeTop > obstacleBottom);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }
        if (!freezeShape) {
            shapeY += fallingShape;
            if (checkCollision(tree, treeX, treeY, treeSize, treeSize) ||
                    checkCollision(stone, stoneX, stoneY, stoneSize, stoneSize) ||
                    checkCollision(leaf, leafX, leafY, leafSize, leafSize)) {
                freezeShape = true;
            }
        }
        if (shapeY + shapeSize >= slotY && !shapeProc) {

            int targetSlotX = getTargetSlotX();


            if (isShapeInCorrectSlot()) {
                int pointsEarned = getPointsEarned();
                score += pointsEarned;
                // System.out.println("GamePanel (Level 4): Shape matched! Earned " + pointsEarned + " points. Current score: " + score); // Debug print
                sorted++;
                if(currentShape.equals("Diamond")) {diamondSort++;} // Corrected casing
                else if(currentShape.equals("Moon")) {moonSort++;}
                else if(currentShape.equals("Cloud")) {cloudSort++;}

                else if(currentShape.equals("Square")) {squareSort++;} // Corrected casing
                shapeProc = true;
                shuffle();
                moveObstaclesDown();
                if (sorted >= totalToWin) {
                    gameWin = true;
                    timer.stop();
                    SwingUtilities.invokeLater(() -> {
                        parentFrame.addToTotalScore(score);
                        parentFrame.unlockLevel(5, score); // Unlock Level 5
                    });
                    count.stop();
                    repaint();
                    return;
                }
                spawnNewShape();
            } }
        if (shapeY > panelHeight + shapeSize && !shapeProc) {
            score -= 5;
            moveObstaclesDown();
            if (currentShape.equals("Diamond")) {
                missedDiamond++;
            } else if (currentShape.equals("Moon")) {
                missedMoon++;
            } else if (currentShape.equals("Cloud")) {
                missedCloud++;
            }

            else if (currentShape.equals("Square")) {
                missedSquare++;
            }
            shapeProc = true;
            spawnNewShape();
        }
        repaint();
    }


    private int getPointsEarned() {
        int basePoints;
        switch (currentShape) {
            case "Diamond": basePoints = 70; break; // Corrected casing
            case "Moon": basePoints = 60; break;
            case "Cloud": basePoints = 80; break;

            case "Square": basePoints = 40; break; // Corrected casing
            default: basePoints = 10;
        }
        int timeBonus = Math.max(0, timeLeft / 15); // Adjusted time bonus
        return basePoints + timeBonus;
    }

    private boolean isShapeInCorrectSlot() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return isShapePerfectlyAligned(slotPos[i]);
            }
        }
        return false;
    }

    private boolean isShapePerfectlyAligned(int targetSlotX) {
        boolean xMatch = Math.abs(shapeX - targetSlotX) <= tolerance;
        boolean yMatch = Math.abs(shapeY - slotY) <= tolerance;
        return xMatch && yMatch;
    }

    private int getTargetSlotX() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return slotPos[i];
            }
        }
        return -1;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
        if (gameStarted && !gameOver && !gameWin) {
            BufferedImage currentShapeImg = getCurrentShapeImage();
            if (currentShapeImg != null) {
                g.drawImage(currentShapeImg, shapeX, shapeY, shapeSize, shapeSize, this);
            }
            drawSlots(g);
            if (tree != null) g.drawImage(tree, treeX, treeY, treeSize, treeSize, this);
            if (stone != null) g.drawImage(stone, stoneX, stoneY, stoneSize, stoneSize, this);
            if (leaf != null) g.drawImage(leaf, leafX, leafY, leafSize, leafSize, this);
            drawVisualGuides(g);
        }
        drawGameStats(g);
        if (gameOver) {
            drawGameOverScreen(g);
        } else if (gameWin) {
            drawWinScreen(g);
        }
    }

    private void drawSlots(Graphics g) {
        for (int i = 0; i < slotShape.length; i++) {
            switch (slotShape[i]) {
                case "Diamond": // Corrected from "Star"
                    // Draw the diamond image for the slot
                    if (diamond != null) {
                        g.drawImage(diamond, slotPos[i], slotY, shapeSize, shapeSize, this);
                    }
                    if (currentShape.equals("Diamond")) { // Corrected casing
                        g.setColor(Color.ORANGE);
                        g.drawRect(slotPos[i] - tolerance, slotY - tolerance,
                                shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                    }
                    break;
                case "Moon":
                    if (moon!= null) {
                        g.drawImage(moon, slotPos[i], slotY, shapeSize, shapeSize, this);
                    }
                    if (currentShape.equals("Moon")) { // Corrected casing
                        g.setColor(Color.BLACK);
                        g.drawRect(slotPos[i] - tolerance, slotY - tolerance,
                                shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                    }
                    break;
                case "Square":
                    g.setColor(Color.YELLOW);
                    g.fillRect(slotPos[i], slotY, shapeSize, shapeSize);
                    if (currentShape.equals("Square")) {
                        g.setColor(Color.ORANGE);
                        g.drawRect(slotPos[i] - tolerance, slotY - tolerance, shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                    }
                    break;


                case "Cloud": // Corrected from "cloud"
                    if (cloud != null) {
                        g.drawImage(cloud, slotPos[i], slotY, shapeSize, shapeSize, this);
                    }
                    if (currentShape.equals("Cloud")) { // Corrected casing
                        g.setColor(Color.BLUE);
                        g.drawRect(slotPos[i] - tolerance, slotY - tolerance,
                                shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                    }
                    break;

            }
        }
    }

    private void drawVisualGuides(Graphics g) {
        int targetSlotX = getTargetSlotX();
        if (targetSlotX != -1) {
            g.setColor(new Color(255, 255, 0, 50));
            if (Math.abs(shapeX - targetSlotX) <= visualGuide) {
                g.fillRect(targetSlotX, 0, shapeSize, panelHeight);
            }
            if (Math.abs(shapeY - slotY) <= visualGuide) {
                g.fillRect(0, slotY, panelWidth, shapeSize);
            }
            if (Math.abs(shapeX - targetSlotX) <= tolerance && Math.abs(shapeY - slotY) <= tolerance) {
                g.setColor(new Color(0, 255, 0, 100));
                g.fillRect(targetSlotX - 2, slotY - 2, shapeSize + 4, shapeSize + 4);
            }
        }
    }

    private void drawGameStats(Graphics g) {
        if (gameStarted) {
            g.setColor(new Color(0, 0, 0, 180));
            g.fillRoundRect(700, 50, 300, 350, 20, 20);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 16));
            int tX = 715;
            int tY = 70;
            int gapText= 20;
            g.setColor(Color.YELLOW);
            g.setFont(new Font("Arial", Font.BOLD, 25));
            g.drawString("LEVEL 4 ", tX, tY);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Segoe UI Emoji", Font.BOLD, 16));
            g.drawString("Score: " + score, tX, tY + gapText);
            g.drawString("Sorted: " + sorted + "/" + totalToWin, tX, tY +gapText*2);
            g.drawString("Time: " + timeLeft + "s", tX, tY + gapText*3);
            g.drawString("💎 ✅ " + diamondSort +" ❌ "+missedDiamond,tX, tY + gapText * 5); // Corrected casing
            g.drawString("🌙 ✅ " + moonSort +" ❌ "+missedMoon,tX, tY + gapText * 7);
            g.drawString("☁ ✅ " + cloudSort +" ❌ "+missedCloud,tX, tY + gapText * 9);

            g.drawString("🟨 ✅ " + squareSort +" ❌ "+missedSquare,tX, tY + gapText * 9); // Corrected casing
        }
    }

    private void drawGameOverScreen(Graphics g) {
        // Remove existing buttons to prevent duplication
        removeAll();
        revalidate();
        repaint();

        g.setColor(new Color(0, 0, 0, 200));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.RED);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        String gameOverText = "GAME OVER";
        g.drawString(gameOverText, panelWidth/2, panelHeight / 2 - 50);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        String scoreText = "Final Score: " + score;

        g.drawString(scoreText, panelWidth/2-50, panelHeight / 2);

        // Re-add buttons after clearing
        add(restart);
        add(backToMenu);
        restart.setVisible(true);
        backToMenu.setVisible(true);
    }

    private void drawWinScreen(Graphics g) {
        // Remove existing buttons to prevent duplication
        removeAll();
        revalidate();
        repaint();

        g.setColor(new Color(0, 100, 0, 200));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(Color.YELLOW);
        g.setFont(new Font("Arial", Font.BOLD, 48));
        String winText = "YOU WIN!";

        g.drawString(winText, panelWidth/2, panelHeight / 2 - 50);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 24));
        String scoreText = "Score: " + score;

        g.drawString(scoreText, panelWidth/2-40, panelHeight / 2);

        // Re-add buttons after clearing
        add(restart);
        add(backToMenu);
        add(nextLevel); // Add next level button
        restart.setVisible(true);
        backToMenu.setVisible(true);
        nextLevel.setVisible(true);
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                shapeX -= 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_RIGHT:
                shapeX += 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_UP: // Fine tune UP (vertical movement)
                shapeY -= 1;
                freezeShape = false;
                break;
            case KeyEvent.VK_DOWN: // Fine tune DOWN (vertical movement)
                shapeY += 1;
                freezeShape = false;
                break;
        }

        if (shapeY < 0) shapeY = 0; // Prevent going above top
        if (shapeY > panelHeight - shapeSize) shapeY = panelHeight - shapeSize; // Prevent going below bottom
        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    public int getScore() {
        return score;
    }
}