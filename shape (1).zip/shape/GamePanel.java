import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class GamePanel extends JPanel implements ActionListener, KeyListener {
    int panelWidth = 450;
    int panelHeight = 580;
    int shapeSize = 60;
    int shapeX, shapeY;
    int slotY;
    int circleSlotX = 170;
    int squareSlotX = 260;
    int triangleSlotX = 350;
    int score = 0;
    int sorted = 0;
    int totalToWin = 2;
    int timeLEft = 60;
    Timer count;
    int tolerance = 5;
    int visualGuide = 10;
    BufferedImage backgroundImage;
    BufferedImage piImage;
    BufferedImage leaf;
    BufferedImage tree;
    BufferedImage stone;
    BufferedImage circle;
    BufferedImage triangle;
    BufferedImage square;
    public boolean freezeShape = false;
    boolean gameStarted = false;
    boolean gameWin = false;
    boolean gameOver = false;
    boolean shapeProc = false;
    boolean soundEnabled = true;
    String currentShape;
    int circleSort = 0;
    int squareSort = 0;
    int triangleSort = 0;
    int missedTriangle = 0;
    int missedSquare = 0;
    int missedCircle = 0;
    int fallingShape = 4;
    int leafX, leafY, treeX, treeY, stoneX, stoneY;
    int leafSize = 60;
    int treeSize = 50;
    int stoneSize = 60;
    int obstacleDown = 30;
    String[] shapes = {"Circle", "Square", "Triangle"};
    String[] slotShape = {"Square", "Circle", "Triangle"};
    int[] slotPos = {squareSlotX, circleSlotX, triangleSlotX};
    int shapeIndex = 0;
    public JButton play;
    public JButton restart;
    public JButton Level2;
    public JButton Level3;
    public Clip startSound;
    public Timer timer;
    public Main parentFrame; // Changed from JFrame to Main
    private Level2 level2Panel;

    public GamePanel(Main parentFrame) { // Changed parameter type
        this.parentFrame = parentFrame;
        setPreferredSize(new Dimension(500, 900));
        setBackground(Color.white);
        setLayout(null);
        play = new JButton("Level1");
        play.setBounds(panelWidth / 2 + 180, panelHeight / 2, 120, 50);
        play.setForeground(Color.blue);
        play.addActionListener(e -> startGame());
        play.setVisible(true); // Make play button visible initially
        this.add(play);
        Level2 = new JButton("Level2");
        Level2.setBounds(panelWidth / 2 + 180, panelHeight / 2 + 60, 120, 50);
        Level2.setForeground(Color.cyan);
        Level2.setVisible(false);
        Level2.addActionListener(e -> checkAndSwitchToLevel2());
        add(Level2);

        timer = new Timer(40, this);
        addKeyListener(this);

        restart = new JButton("Restart");
        restart.setBounds(panelWidth / 2 + 180, panelHeight / 2, 90, 50);
        restart.setForeground(Color.cyan);
        this.add(restart);
        restart.addActionListener(e -> restart());
        restart.setVisible(false);

        loadSounds();
        createShapeBufferedImages();
        loadBufferedImages();
        setFocusable(true);
    }

    private void checkAndSwitchToLevel2() {
        // Check if Level 1 is completed before allowing access to Level 2
        if (!gameWin) { // This condition might need to check a persistent state from parentFrame
            JOptionPane.showMessageDialog(this,
                    "Complete Level 1 first to unlock Level 2!",
                    "Level Locked",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        startNextLevel();
    }

    private void loadSounds() {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(
                    getClass().getResource("/st.wav"));
            startSound = AudioSystem.getClip();
            startSound.open(audioInputStream);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    private void playSound(Clip clip) {
        if (!soundEnabled || clip == null) {
            return;
        }
        SwingUtilities.invokeLater(() -> {
            try {
                if (clip.isRunning()) {
                    clip.stop();
                }
                clip.setFramePosition(0);
                try {
                    FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    gainControl.setValue(-10.0f);
                } catch (Exception e) {
                    // Volume control not available, continue without it
                }
                //clip.start();
                clip.loop(Clip.LOOP_CONTINUOUSLY);
            } catch (Exception e) {
                System.out.println("Error playing sound: " + e.getMessage());
            }
        });
    }


private void stopBackSound(Clip clip)
{if(clip!=null && clip.isRunning())
{ SwingUtilities.invokeLater(()->
{ clip.stop();clip.setFramePosition(0);});}}


    public void switchBackLevel1() {
        JFrame currentFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
        if (currentFrame != null) {
            currentFrame.getContentPane().removeAll();
           stopBackSound(startSound);
            currentFrame.add(this);
            currentFrame.revalidate();
            currentFrame.repaint();
            this.requestFocusInWindow();
        }
    }
private void startNextLevel() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        // Clear buttons before starting next level
        removeAll();
        revalidate();
        repaint();
        parentFrame.startLevel(2); // Assuming Level 5 is the next level
    }

    public void createShapeBufferedImages() {
        backgroundImage = new BufferedImage(panelWidth, panelHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = backgroundImage.createGraphics();
        GradientPaint gradient = new GradientPaint(0, 0, new Color(25, 112, 67), panelWidth, panelHeight, new Color(20, 224, 50));
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, panelWidth, panelHeight);
        g2d.dispose(); // Dispose the graphics context for backgroundImage creation

        circle = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = circle.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.GREEN);
        g2d.fillOval(0, 0, shapeSize, shapeSize);
        g2d.dispose();

        square = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = square.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.RED);
        g2d.fillRect(0, 0, shapeSize, shapeSize);
        g2d.dispose();

        triangle = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        g2d = triangle.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(Color.ORANGE);
        int[] xp = {shapeSize / 2, 0, shapeSize};
        int[] yp = {0, shapeSize, shapeSize};
        g2d.fillPolygon(xp, yp, 3);
        g2d.dispose();
    }

    private void loadBufferedImages() {
        try {
            leaf = ImageIO.read(getClass().getResource("/leaf.png"));
            tree = ImageIO.read(getClass().getResource("/tree.png"));
            stone = ImageIO.read(getClass().getResource("/stone.png"));
            backgroundImage = ImageIO.read(getClass().getResource("/bi.png"));
            piImage = ImageIO.read(getClass().getResource("/pi.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void startGame() {
        score = 0;
        sorted = 0;
        totalToWin = 2; // Ensure totalToWin is 2 for Level 1
        circleSort = 0;
        squareSort = 0;
        triangleSort = 0;
        missedCircle = 0;
        missedTriangle = 0;
        missedSquare = 0;
        shapeIndex = 0;
        timeLEft = 60;

        gameStarted = true;
        gameOver = false;
        gameWin = false;
        slotY = panelHeight -30;
        spawnNewShape();
        spawnObstacles();

        play.setVisible(false);
        Level2.setVisible(false); // Hide Level2 button when game starts

        if (count != null) {
            count.stop();
        }
        count = new Timer(1000, e -> {
            timeLEft--;
            if (timeLEft <= 0) {
                gameOver = true;
                count.stop();
                timer.stop();
                repaint();
            }
        });
        count.start();
        restart.setVisible(false);
        timer.start();
        requestFocusInWindow();
        playSound(startSound);
        repaint();
    }

    public void restart() {
        score = 0;
        sorted = 0;
        totalToWin = 2; // Reset totalToWin to 2 for Level 1 restart
        circleSort = 0;
        squareSort = 0;
        triangleSort = 0;
        missedCircle = 0;
        missedTriangle = 0;
        missedSquare = 0;
        shapeIndex = 0;
        timeLEft = 60;

        gameStarted = true;
        gameWin = false;
        gameOver = false;
        restart.setVisible(false);
        Level2.setVisible(false); // Hide Level2 button on restart
        play.setVisible(false); // Hide play button on restart

        spawnNewShape();
        spawnObstacles();
        timer.start();
        requestFocusInWindow();
        repaint();

        if (count != null) {
            count.stop();
        }
        count = new Timer(1000, e -> {
            timeLEft--;
            if (timeLEft <= 0) {
                gameOver = true;
                count.stop();
                timer.stop();
                repaint();
            }
        });
        count.start();
    }

    public void spawnObstacles() {
        leafX = panelWidth / 2 - 30;
        leafY = 75;
        treeX = panelWidth / 2 + 70;
        treeY = 100;
        stoneX = panelWidth / 2;
        stoneY = 350;
    }

    public void shuffle() {
        java.util.List<String> shapeList = new ArrayList<>(Arrays.asList(slotShape));
        java.util.List<Integer> posList = new ArrayList<>();
        for (int pos : slotPos) {
            posList.add(pos);
        }
        Collections.shuffle(shapeList);
        Collections.shuffle(posList);
        for (int i = 0; i < slotShape.length; i++) {
            slotShape[i] = shapeList.get(i);
            slotPos[i] = posList.get(i);
        }
    }

    public void spawnNewShape() {
        currentShape = shapes[shapeIndex];
        shapeX = panelWidth / 2;
        shapeY = 0;
        shapeIndex++;
        if (shapeIndex >= shapes.length) {
            shapeIndex = 0;
        }
        shuffle();
        freezeShape = false;
        shapeProc = false;
    }

    public void movesObstacleDown() {
        leafY += obstacleDown;
        treeY += obstacleDown;
        stoneY += obstacleDown;
        if (leafY > panelHeight - 100) {
            leafY = 50 + (int) (Math.random() * 50);
            leafX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (treeY > panelHeight - 100) {
            treeY = 50 + (int) (Math.random() * 50);
            treeX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (stoneY > panelHeight - 100) {
            stoneY = 50 + (int) (Math.random() * 50);
            stoneX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (Math.random() > 0.5) {
            int tempX = leafX;
            leafX = treeX;
            treeX = tempX;
        }
        if (Math.random() > 0.5) {
            int tempX = stoneX;
            stoneX = leafX;
            leafX = tempX;
        }
    }

    private BufferedImage getCurrentShapeImage() {
        switch (currentShape) {
            case "Circle":
                return circle;
            case "Square":
                return square;
            case "Triangle":
                return triangle;
            default:
                return null;
        }
    }

    private boolean isPixelOpaque(BufferedImage img, int x, int y) {
        if (img == null) {
            return false;
        }
        if (x < 0 || y < 0 || x >= img.getWidth() || y >= img.getHeight()) return false;
        int pixel = img.getRGB(x, y);
        int alpha = (pixel >> 24) & 0xff;
        return alpha > 0;
    }

    private boolean CheckCollision(BufferedImage obstacle, int obstacleX, int obstacleY, int obstacleWidth, int obstacleHeight) {
        BufferedImage shapeImg = getCurrentShapeImage();
        if (shapeImg == null || obstacle == null) {
            return false;
        }
        int shapeLeft = shapeX;
        int shapeRight = shapeX + shapeSize;
        int shapeTop = shapeY;
        int shapeBottom = shapeY + shapeSize;

        int obstacleLeft = obstacleX;
        int obstacleRight = obstacleX + obstacleWidth;
        int obstacleTop = obstacleY;
        int obstacleBottom = obstacleY + obstacleHeight;

        if (shapeRight < obstacleLeft || shapeLeft > obstacleRight || shapeBottom < obstacleTop || shapeTop > obstacleBottom) {
            return false;
        }

        int overlapLeft = Math.max(shapeLeft, obstacleLeft);
        int overlapRight = Math.min(shapeRight, obstacleRight);
        int overlapBottom = Math.min(shapeBottom, obstacleBottom);
        int overlapTop = Math.max(shapeTop, obstacleTop);

        double shapeScaleX = shapeImg.getWidth() / (double) shapeSize;
        double shapeScaleY = shapeImg.getHeight() / (double) shapeSize;
        double obstacleScaleX = obstacle.getWidth() / (double) obstacleWidth;
        double obstacleScaleY = obstacle.getHeight() / (double) obstacleHeight;

        for (int y = overlapTop; y < overlapBottom; y += 2) {
            for (int x = overlapLeft; x < overlapRight; x += 2) {
                int shapePixelX = (int) ((x - shapeLeft) * shapeScaleX);
                int obstaclePixelX = (int) ((x - obstacleLeft) * obstacleScaleX);
                int obstaclePixelY = (int) ((y - obstacleTop) * obstacleScaleY);
                int shapePixelY = (int) ((y - shapeTop) * shapeScaleY);

                if (isPixelOpaque(shapeImg, shapePixelX, shapePixelY) && isPixelOpaque(obstacle, obstaclePixelX, obstaclePixelY)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }

        if (!freezeShape) {
            shapeY += fallingShape;
            if (CheckCollision(leaf, leafX, leafY, leafSize, leafSize) ||
                    CheckCollision(tree, treeX, treeY, treeSize, treeSize) ||
                    CheckCollision(stone, stoneX, stoneY, stoneSize, stoneSize)) {
                freezeShape = true;
            }
        }

        if (shapeY + shapeSize >= slotY && !shapeProc) {
            if (isShapeinCorrectSlot()) {
                int pointsEarn = getPointsEarn();
                score += pointsEarn;
                sorted++; // Increment sorted count
                if (currentShape.equals("Circle")) {
                    circleSort++;
                } else if (currentShape.equals("Square")) {
                    squareSort++;
                } else if (currentShape.equals("Triangle")) {
                    triangleSort++;
                }
                shapeProc = true;
                shuffle();
                movesObstacleDown();

                if (sorted >= totalToWin) {
                    gameWin = true;
                    timer.stop();
                    count.stop(); // Stop time count as well

                    // Ensure the UI updates with the final sorted count before showing the dialog
                    repaint();

                    // Show dialog after repaint, this will block until dismissed
                    JOptionPane.showMessageDialog(this, "Congratulations! You've completed Level 1!", "Level Complete", JOptionPane.INFORMATION_MESSAGE);

                    // Perform actions after the dialog is dismissed
                    parentFrame.unlockLevel(1, score); // Mark Level 1 as completed
                    parentFrame.unlockLevel(2, score); // Unlock Level 2
                    parentFrame.returnToMenu(); // Return to the main menu

                    return; // Stop further processing in this actionPerformed cycle
                }
                spawnNewShape();
            }
        }

        if (shapeY > panelHeight + shapeSize && !shapeProc) {
            score -= 5;
            movesObstacleDown();
            if (currentShape.equals("Circle")) {
                missedCircle++;
            } else if (currentShape.equals("Square")) {
                missedSquare++;
            } else if (currentShape.equals("Triangle")) {
                missedTriangle++;
            }
            shapeProc = true;
            spawnNewShape();
        }
        repaint();
    }

    private int getPointsEarn() {
        int basePoints;
        switch (currentShape) {
            case "Circle":
                basePoints = 30;
                break;
            case "Square":
                basePoints = 40;
                break;
            case "Triangle":
                basePoints = 50;
                break;
            default:
                basePoints = 10;
        }
        return basePoints;
    }

    private boolean isShapeinCorrectSlot() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return isShapePerfect(slotPos[i]);
            }
        }
        return false;
    }

    private boolean isShapePerfect(int targetSlotX) {
        boolean xMatch = Math.abs(shapeX - targetSlotX) <= tolerance;
        boolean yMatch = Math.abs(shapeY - slotY) <= tolerance;
        return xMatch && yMatch;
    }

    private int getTargetSlotX() {
        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return slotPos[i];
            }
        }
        return -1;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (!gameStarted && play.isVisible()) {
            g.drawImage(piImage, 0, 0, getWidth(), getHeight(), this);
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.PLAIN, 16));
            g.drawString("Shape Sorter", panelWidth / 2 - 100, panelHeight / 2 - 100);
            g.setFont(new Font("Arial", Font.PLAIN, 16));
            g.drawString("Level 1:Circle ,Square,Triangle", panelWidth / 2 - 80, panelHeight / 2 - 30);
        }

        if (gameStarted && !gameOver && !gameWin) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            BufferedImage currentShapeImg = getCurrentShapeImage();
            if (currentShapeImg != null) {
                g.drawImage(currentShapeImg, shapeX, shapeY, shapeSize, shapeSize, this);
            }

            for (int i = 0; i < slotShape.length; i++) {
                switch (slotShape[i]) {
                    case "Circle":
                        g.setColor(Color.magenta);
                        g.fillOval(slotPos[i], slotY, shapeSize, shapeSize);
                        if (currentShape.equals("Circle")) {
                            g.setColor(Color.ORANGE);
                            g.drawOval(slotPos[i] - tolerance, slotY - tolerance, shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                        }
                        break;
                    case "Square":
                        g.setColor(Color.YELLOW);
                        g.fillRect(slotPos[i], slotY, shapeSize, shapeSize);
                        if (currentShape.equals("Square")) {
                            g.setColor(Color.ORANGE);
                            g.drawRect(slotPos[i] - tolerance, slotY - tolerance, shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                        }
                        break;
                    case "Triangle":
                        g.setColor(Color.pink);
                        int[] x = {slotPos[i] + shapeSize / 2, slotPos[i], slotPos[i] + shapeSize};
                        int[] y = {slotY, slotY + shapeSize, slotY + shapeSize};
                        g.fillPolygon(x, y, 3);
                        if (currentShape.equals("Triangle")) {
                            g.setColor(Color.BLUE);
                            int[] outX = {slotPos[i] + shapeSize / 2, slotPos[i] - tolerance, slotPos[i] + shapeSize + tolerance};
                            int[] outY = {slotY - tolerance, slotY + shapeSize + tolerance, slotY + shapeSize + tolerance};
                            g.fillPolygon(outX, outY, 3);
                        }
                        break;
                }
            }

            g.drawImage(leaf, leafX, leafY, leafSize, leafSize, this);
            g.drawImage(tree, treeX, treeY, treeSize, treeSize, this);
            g.drawImage(stone, stoneX, stoneY, stoneSize, stoneSize, this);

            int targetSlotX = getTargetSlotX();
            if (targetSlotX != -1) {
                g.setColor(new Color(10, 0, 20, 67));
                if (Math.abs(shapeX - targetSlotX) <= visualGuide) {
                    g.fillRect(targetSlotX, 0, shapeSize, panelHeight);
                    g.setColor(Color.WHITE);
                    g.drawString(Math.abs(shapeX - targetSlotX) + "px", targetSlotX + shapeSize + 5, shapeY + shapeSize / 2);
                }
                if (Math.abs(shapeY - slotY) <= visualGuide) {
                    g.fillRect(0, slotY, panelWidth, shapeSize);
                    g.setColor(Color.WHITE);
                    g.drawString(Math.abs(shapeY - slotY) + "px", shapeX + shapeSize + 5, shapeY + shapeSize / 2);
                }
                if (Math.abs(shapeX - targetSlotX) <= tolerance && Math.abs(shapeY - slotY) <= tolerance) {
                    g.setColor(new Color(0, 255, 0, 100));
                    g.fillRect(targetSlotX - 2, slotY - 2, shapeSize + 4, shapeSize + 4);
                }
            }
        }

        if (gameStarted) {
            g.setColor(new Color(0, 0, 0,180));
            g.fillRoundRect(700, 50, 200, 280, 40, 40);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Adobe Devanagari", Font.BOLD, 18));
            int tX = 715;
            int tY = 75;
            int gapText = 20;
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("Level: 1", tX, tY);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Segoe UI Emoji", Font.BOLD, 18));
            g.drawString("Score:" + score, tX, tY + gapText);
            g.drawString("Total Sorted:" + sorted, tX, tY + gapText * 2); // This will now show the correct value
            g.drawString("⚪✅ " + circleSort + " ❌" + missedCircle, tX, tY + gapText * 5);
            g.drawString("🔺✅ " + triangleSort + "❌" + missedTriangle, tX, tY + gapText * 7);
            g.drawString(" 🟨 ✅ " + squareSort + "❌" + missedSquare, tX, tY + gapText * 9);
            g.drawString("Time Left:" + timeLEft, tX, tY + gapText * 11);
        }

        if (gameOver) {
            g.setColor(Color.gray);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("Game Over", panelWidth / 2 + 50, panelHeight / 2 - 50);
            g.drawString("Final Score: " + score, panelWidth / 2 + 50, panelHeight / 2 - 20);
            restart.setVisible(true);
            play.setVisible(true);
            Level2.setVisible(false); // Don't show Level2 button on game over
        } else if (gameWin) {
            g.setColor(Color.BLUE);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("Level 1 Complete!", panelWidth / 2 + 50, panelHeight / 2 - 10);
            g.drawString("🔓 Level 2 Unlocked!", panelWidth / 2 + 50, panelHeight / 2 + 20);
            restart.setVisible(true);
            Level2.setVisible(true);
            // Removed JOptionPane.showMessageDialog and parentFrame calls from here
            // These actions are now handled in actionPerformed after the dialog
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            shapeX -= 10;
            freezeShape = false;
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            shapeX += 10;
            freezeShape = false;
        } else if (e.getKeyCode() == KeyEvent.VK_UP) {
            shapeX -= 1;
            freezeShape = false;
        } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            shapeX += 1;
            freezeShape = false;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public int getScore() {
        return score;
    }

    public void addScore(int points) {
        this.score += points;
    }

    public void setName() {
        // Empty method
    }

    public void switchBackToLevel1() {
        // Empty method
    }
}