

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Level5 extends JPanel implements ActionListener, KeyListener {
    // Game dimensions and settings
    int panelWidth = 450;
    int panelHeight = 580;
    int shapeSize = 85;
    int shapeX, shapeY;
    int slotY;
    int hexagonSlotX = 150;
    int nonagonSlotX = 250;
    int heartSlotX = 350;

    // Game state variables
    int score = 0;
    int sorted = 0;
    int totalToWin = 20;
    int timeLeft = 120;
    Timer count;
    int tolerance = 10;
    int visualGuide = 10;

    // Images - Regular shapes
    BufferedImage backgroundImage;
    BufferedImage leaf, tree, stone, spweb;
    BufferedImage hexagon, nonagon, heart;

    // Images - Irregular shapes (loaded from files)
    BufferedImage puzzle, cross, spiral, lightning;

    // Game state flags
    public boolean freezeShape = false;
    boolean gameStarted = false;
    boolean gameWin = false;
    boolean gameOver = false;
    boolean shapeProc = false;

    // Shape and scoring variables
    String currentShape = "Heart"; // Initialize with default value
    boolean isCurrentShapeIrregular = false;
    int heartSort = 0, nonagonSort = 0, hexagonSort = 0;
    int missedHexagon = 0, missedNonagon = 0, missedHeart = 0;
    int irregularCollected = 0;
    int fallingShape = 15;

    // Obstacle variables
    int leafX, leafY, treeX, treeY, stoneX, stoneY, spwebX, spwebY;
    int leafSize = 55, treeSize = 45, stoneSize = 55, spwebSize = 60;
    int obstacleDown = 20;

    // Game arrays
    String[] regularShapes = {"Hexagon", "Nonagon", "Heart"};
    String[] irregularShapes = {"Cross", "Spiral", "Lightning"};
    String[] slotShape = {"Heart", "Nonagon", "Hexagon"};
    int[] slotPos = {heartSlotX, nonagonSlotX, hexagonSlotX};
    int shapeIndex = 0;

    // Irregular shapes collection area
    List<IrregularShape> collectedIrregularShapes = new ArrayList<>();
    int irregularAreaX = panelWidth + 20;
    int irregularAreaY = 50;

    // UI Components
    public JButton restart;
    public JButton backToMenu;
    public JButton startButton;
    public Clip matchSound;
    public Timer timer;
    private Main parentFrame;
    private GamePanel level1Panel;
    private Random random = new Random();

    // Inner class for irregular shapes
    private static class IrregularShape {
        String type;
        int x, y;
        Color color;
        BufferedImage image;

        IrregularShape(String type, int x, int y, Color color, BufferedImage image) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.color = color;
            this.image = image;
        }
    }

    public Level5(Main parentFrame, GamePanel level1Panel) {
        this.parentFrame = parentFrame;
        this.level1Panel = level1Panel;
        setPreferredSize(new Dimension(1000, 700));
        setBackground(Color.BLACK);
        setLayout(null);

        // Initialize game state first
        slotY = panelHeight - 30;

        // Create images before initializing buttons
        createRegularShapeBufferedImages();
        loadAllBufferedImages();

        initializeButtons();
        timer = new Timer(10, this);
        addKeyListener(this);
        setFocusable(true);

        spawnObstacles();
    }

    private void initializeButtons() {
        // Start button (visible initially)
        startButton = new JButton("Start Game");
        startButton.setBounds(panelWidth / 2 - 50, panelHeight / 2, 100, 50);
        startButton.setForeground(Color.GREEN);
        startButton.setBackground(Color.DARK_GRAY);
        startButton.addActionListener(e -> startGame());
        startButton.setVisible(true);
        this.add(startButton);

        restart = new JButton("Restart");
        restart.setBounds(panelWidth + 50, panelHeight / 2, 90, 50);
        restart.setForeground(Color.CYAN);
        restart.addActionListener(e -> restart());
        restart.setVisible(false);
        this.add(restart);

        backToMenu = new JButton("Main Menu");
        backToMenu.setBounds(panelWidth + 150, panelHeight / 2, 100, 50);
        backToMenu.setForeground(Color.ORANGE);
        backToMenu.addActionListener(e -> returnToMainMenu());
        backToMenu.setVisible(false);
        this.add(backToMenu);
    }

    private void returnToMainMenu() {
        if (timer != null) timer.stop();
        if (count != null) count.stop();
        if (parentFrame != null) {
            parentFrame.addToTotalScore(score);
            parentFrame.returnToMenu();
        }
    }

    public void createRegularShapeBufferedImages() {
        try {
            // Create hexagon
            hexagon = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = hexagon.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(Color.YELLOW);
            int[] hexX = new int[6];
            int[] hexY = new int[6];
            int centerX = shapeSize / 2;
            int centerY = shapeSize / 2;
            int radius = shapeSize / 2 - 2;
            for (int i = 0; i < 6; i++) {
                double angle = 2 * Math.PI * i / 6;
                hexX[i] = centerX + (int) (radius * Math.cos(angle));
                hexY[i] = centerY + (int) (radius * Math.sin(angle));
            }
            g2d.fillPolygon(hexX, hexY, 6);
            g2d.setColor(Color.YELLOW.darker());
            g2d.setStroke(new BasicStroke(2));
            g2d.drawPolygon(hexX, hexY, 6);
            g2d.dispose();

            // Create nonagon
            nonagon = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
            g2d = nonagon.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(Color.PINK);
            int[] nonX = new int[9];
            int[] nonY = new int[9];
            centerX = shapeSize / 2;
            centerY = shapeSize / 2;
            radius = shapeSize / 2 - 2;
            for (int i = 0; i < 9; i++) {
                double angle = 2 * Math.PI * i / 9 - Math.PI / 2;
                nonX[i] = centerX + (int) (radius * Math.cos(angle));
                nonY[i] = centerY + (int) (radius * Math.sin(angle));
            }
            g2d.fillPolygon(nonX, nonY, 9);
            g2d.setColor(Color.PINK.darker());
            g2d.setStroke(new BasicStroke(2));
            g2d.drawPolygon(nonX, nonY, 9);
            g2d.dispose();


//            g2d.dispose();
        } catch (Exception e) {
            System.err.println("Error creating regular shapes: " + e.getMessage());
            e.printStackTrace();
        }
    }
    private void loadAllBufferedImages() {
        try {
            leaf = ImageIO.read(getClass().getResource("/leaf.png"));
            tree = ImageIO.read(getClass().getResource("/tree.png"));
            stone = ImageIO.read(getClass().getResource("/stone.png"));
            spweb = ImageIO.read(getClass().getResource("/spweb.png"));
            spiral= ImageIO.read(getClass().getResource("/spiral.png"));
            cross= ImageIO.read(getClass().getResource("/cross.png"));
            heart= ImageIO.read(getClass().getResource("/heart.png"));
            lightning=ImageIO.read(getClass().getResource("/lightning.png"));// Load diamond image
            backgroundImage = ImageIO.read(getClass().getResource("/lv5.jpg")); // New background for Level 4
        } catch (IOException e) {
            e.printStackTrace();
            createFallbackImages();
        }
    }


    private BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        if (originalImage == null) return null;

        try {
            BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = resizedImage.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.drawImage(originalImage, 0, 0, targetWidth, targetHeight, null);
            g2d.dispose();
            return resizedImage;
        } catch (Exception e) {
            System.err.println("Error resizing image: " + e.getMessage());
            return originalImage;
        }
    }

    private void createFallbackImages() {
        // Create fallback background
        if (backgroundImage == null) {
            backgroundImage = new BufferedImage(panelWidth, panelHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = backgroundImage.createGraphics();
            GradientPaint gradient = new GradientPaint(0, 0, new Color(25, 25, 112), panelWidth, panelHeight, new Color(72, 61, 139));
            g2d.setPaint(gradient);
            g2d.fillRect(0, 0, panelWidth, panelHeight);
            // Add stars
            g2d.setColor(Color.WHITE);
            for (int i = 0; i < 50; i++) {
                int x = (int) (Math.random() * panelWidth);
                int y = (int) (Math.random() * panelHeight);
                g2d.fillOval(x, y, 2, 2);
            }
            g2d.dispose();
        }

        // Create simple obstacle images if loading failed
        if (leaf == null) leaf = createSimpleObstacle(leafSize, Color.GREEN);
        if (tree == null) tree = createSimpleObstacle(treeSize, new Color(139, 69, 19));
        if (stone == null) stone = createSimpleObstacle(stoneSize, Color.GRAY);
        if (spweb == null) spweb = createSimpleObstacle(spwebSize, Color.BLACK);

        // Create fallback irregular shapes if loading failed

        if (cross == null) cross = createFallbackIrregularShape("CROSS", Color.BLUE);
        if (spiral == null) spiral = createFallbackIrregularShape("SPIRAL", Color.ORANGE);
        if (lightning == null) lightning = createFallbackIrregularShape("LIGHTNING", Color.MAGENTA);
    }

    private BufferedImage createSimpleObstacle(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(color);
        g2d.fillOval(0, 0, size, size);
        g2d.setColor(color.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawOval(1, 1, size - 2, size - 2);
        g2d.dispose();
        return img;
    }

    private BufferedImage createFallbackIrregularShape(String text, Color color) {
        BufferedImage img = new BufferedImage(shapeSize, shapeSize, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(color);
        g2d.fillRect(10, 10, shapeSize - 20, shapeSize - 20);
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 12));
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(text);
        int textHeight = fm.getHeight();
        g2d.drawString(text, (shapeSize - textWidth) / 2, (shapeSize + textHeight) / 2);
        g2d.setColor(color.darker());
        g2d.setStroke(new BasicStroke(2));
        g2d.drawRect(10, 10, shapeSize - 20, shapeSize - 20);
        g2d.dispose();
        return img;
    }

    public void startGame() {
        gameStarted = true;
        gameOver = false;
        gameWin = false;
        score = 0;
        sorted = 0;
        timeLeft = 120;
        irregularCollected = 0;

        // Reset all counters
        heartSort = hexagonSort = nonagonSort = 0;
        missedHeart = missedHexagon = missedNonagon = 0;
        shapeIndex = 0;
        collectedIrregularShapes.clear();

        // Hide start button, show game
        startButton.setVisible(false);
        restart.setVisible(false);
        backToMenu.setVisible(false);

        spawnNewShape();
        spawnObstacles();

        if (count != null) count.stop();
        count = new Timer(1000, e -> {
            if (!gameOver && !gameWin) {
                timeLeft--;
                if (timeLeft <= 0) {
                    gameOver = true;
                    count.stop();
                    timer.stop();
                    repaint();
                }
            }
        });
        count.start();
        timer.start();
        requestFocusInWindow();
        repaint();
    }

    public void restart() {
        startGame();
    }

    public void spawnObstacles() {
        leafX = panelWidth / 2 - 30;
        leafY = 75;
        treeX = panelWidth / 2 + 70;
        treeY = 100;
        stoneX = panelWidth / 2;
        stoneY = 350;
        spwebX = panelWidth / 2 + 80;
        spwebY = 450;
    }

    public void shuffle() {
        try {
            java.util.List<String> shapeList = new ArrayList<>(Arrays.asList(slotShape));
            java.util.List<Integer> posList = new ArrayList<>();
            for (int pos : slotPos) {
                posList.add(pos);
            }
            Collections.shuffle(shapeList);
            Collections.shuffle(posList);
            for (int i = 0; i < slotShape.length; i++) {
                slotShape[i] = shapeList.get(i);
                slotPos[i] = posList.get(i);
            }
        } catch (Exception e) {
            System.err.println("Error in shuffle: " + e.getMessage());
        }
    }

    public void spawnNewShape() {
        try {
            // Randomly choose between regular and irregular shapes
            boolean spawnIrregular = random.nextDouble() < 0.4; // 40% chance for irregular

            if (spawnIrregular) {
                currentShape = irregularShapes[random.nextInt(irregularShapes.length)];
                isCurrentShapeIrregular = true;
            } else {
                currentShape = regularShapes[shapeIndex];
                isCurrentShapeIrregular = false;
                shapeIndex++;
                if (shapeIndex >= regularShapes.length) {
                    shapeIndex = 0;
                }
            }

            shapeX = panelWidth / 2;
            shapeY = 0;
            shuffle();
            freezeShape = false;
            shapeProc = false;
        } catch (Exception e) {
            System.err.println("Error in spawnNewShape: " + e.getMessage());
            // Fallback to a safe default
            currentShape = "Heart";
            isCurrentShapeIrregular = false;
        }
    }

    public void moveObstaclesDown() {
        leafY += obstacleDown;
        treeY += obstacleDown;
        stoneY += obstacleDown;
        spwebY += obstacleDown;

        if (leafY > panelHeight - 100) {
            leafY = 50 + (int) (Math.random() * 50);
            leafX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (treeY > panelHeight - 100) {
            treeY = 50 + (int) (Math.random() * 50);
            treeX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (stoneY > panelHeight - 100) {
            stoneY = 50 + (int) (Math.random() * 50);
            stoneX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
        if (spwebY > panelHeight - 100) {
            spwebY = 50 + (int) (Math.random() * 50);
            spwebX = 50 + (int) (Math.random() * (panelWidth - 100));
        }
    }

    private BufferedImage getCurrentShapeImage() {
        if (currentShape == null) return heart; // Fallback

        switch (currentShape) {
            case "Heart": return heart;
            case "Hexagon": return hexagon;
            case "Nonagon": return nonagon;
            case "Puzzle": return puzzle;
            case "Cross": return cross;
            case "Spiral": return spiral;
            case "Lightning": return lightning;
            default: return heart; // Fallback
        }
    }

    private boolean checkCollision(BufferedImage obstacle, int obstacleX, int obstacleY, int obstacleWidth, int obstacleHeight) {
        if (obstacle == null) return false;

        int shapeLeft = shapeX;
        int shapeRight = shapeX + shapeSize;
        int shapeTop = shapeY;
        int shapeBottom = shapeY + shapeSize;
        int obstacleLeft = obstacleX;
        int obstacleRight = obstacleX + obstacleWidth;
        int obstacleTop = obstacleY;
        int obstacleBottom = obstacleY + obstacleHeight;
        return !(shapeRight < obstacleLeft || shapeLeft > obstacleRight ||
                shapeBottom < obstacleTop || shapeTop > obstacleBottom);
    }

    private void collectIrregularShape() {
        if (currentShape == null) return;

        Color shapeColor;
        BufferedImage shapeImage;

        switch (currentShape) {

            case "Cross":
                shapeColor = Color.BLUE;
                shapeImage = cross;
                break;
            case "Spiral":
                shapeColor = Color.ORANGE;
                shapeImage = spiral;
                break;
            case "Lightning":
                shapeColor = Color.MAGENTA;
                shapeImage = lightning;
                break;
            default:
                shapeColor = Color.GRAY;
                shapeImage = null;
        }

        int collectionX = irregularAreaX;
        int collectionY = irregularAreaY + (collectedIrregularShapes.size() * (shapeSize / 2 + 5));

        collectedIrregularShapes.add(new IrregularShape(currentShape, collectionX, collectionY, shapeColor, shapeImage));
        irregularCollected++;

        // Apply irregular shape effects
        switch (currentShape) {

            case "Cross":
                score += 30;
                break;
            case "Spiral":
                timeLeft += 10; // Time bonus
                score += 40;
                break;
            case "Lightning":
                score += 60; // High bonus but rare
                break;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (!gameStarted || gameWin || gameOver) {
                repaint(); // Always repaint to show current state
                return;
            }

            if (!freezeShape) {
                shapeY += fallingShape;
                // Check collision with obstacles
                if (checkCollision(leaf, leafX, leafY, leafSize, leafSize) ||
                        checkCollision(tree, treeX, treeY, treeSize, treeSize) ||
                        checkCollision(stone, stoneX, stoneY, stoneSize, stoneSize) ||
                        checkCollision(spweb, spwebX, spwebY, spwebSize, spwebSize)) {
                    freezeShape = true;
                }
            }

            // Check if shape reached the bottom
            if (shapeY + shapeSize >= slotY && !shapeProc) {
                if (isCurrentShapeIrregular) {
                    // Irregular shapes are automatically collected
                    collectIrregularShape();
                    shapeProc = true;
                    moveObstaclesDown();
                    spawnNewShape();
                } else {
                    // Regular shapes need to match slots
                    if (isShapeInCorrectSlot()) {
                        int pointsEarned = getPointsEarned();
                        score += pointsEarned;
                        sorted++;

                        // Update shape-specific counters
                        if (currentShape != null) {
                            if (currentShape.equals("Heart")) {
                                heartSort++;
                            } else if (currentShape.equals("Nonagon")) {
                                nonagonSort++;
                            } else if (currentShape.equals("Hexagon")) {
                                hexagonSort++;
                            }
                        }

                        shapeProc = true;
                        shuffle();
                        moveObstaclesDown();

                        if (sorted >= totalToWin) {
                            gameWin = true;
                            timer.stop();
                            SwingUtilities.invokeLater(() -> {
                                if (parentFrame != null) {
                                    parentFrame.addToTotalScore(score);
                                    parentFrame.unlockLevel(5, score);
                                    parentFrame.returnToMenu();
                                }
                            });
                            count.stop();
                            repaint();
                            return;
                        }
                        spawnNewShape();
                    }
                }
            }

            if (shapeY > panelHeight + shapeSize && !shapeProc) {
                if (!isCurrentShapeIrregular && currentShape != null) {
                    score -= 5;
                    if (currentShape.equals("Heart")) {
                        missedHeart++;
                    } else if (currentShape.equals("Hexagon")) {
                        missedHexagon++;
                    } else if (currentShape.equals("Nonagon")) {
                        missedNonagon++;
                    }
                }
                moveObstaclesDown();
                sorted++;
                shapeProc = true;
                spawnNewShape();
            }

            repaint();
        } catch (Exception ex) {
            System.err.println("Error in actionPerformed: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private int getPointsEarned() {
        if (currentShape == null) return 10;

        int basePoints;
        switch (currentShape) {
            case "Heart": basePoints = 60; break;
            case "Nonagon": basePoints = 80; break;
            case "Hexagon": basePoints = 90; break;
            default: basePoints = 10;
        }
        int timeBonus = Math.max(0, timeLeft / 20);
        return basePoints + timeBonus;
    }

    private boolean isShapeInCorrectSlot() {
        if (currentShape == null) return false;

        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return isShapePerfectlyAligned(slotPos[i]);
            }
        }
        return false;
    }

    private boolean isShapePerfectlyAligned(int targetSlotX) {
        boolean xMatch = Math.abs(shapeX - targetSlotX) <= tolerance;
        boolean yMatch = Math.abs(shapeY - slotY) <= tolerance;
        return xMatch && yMatch;
    }

    private int getTargetSlotX() {
        if (currentShape == null) return -1;

        for (int i = 0; i < slotShape.length; i++) {
            if (currentShape.equals(slotShape[i])) {
                return slotPos[i];
            }
        }
        return -1;
    }

    @Override
    public void paintComponent(Graphics g) {
        try {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Draw background
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            } else {
                // Fallback background
                g.setColor(new Color(25, 25, 112));
                g.fillRect(0, 0, panelWidth, panelHeight);
            }

            // Draw irregular shapes collection area
            g.setColor(new Color(50, 50, 50, 150));
            g.fillRect(irregularAreaX - 10, irregularAreaY - 30, 150, panelHeight - 100);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 14));
            g.drawString("Irregular Shapes", irregularAreaX - 5, irregularAreaY - 10);



           if (gameStarted && !gameOver && !gameWin) {
                // Draw current falling shape
                BufferedImage currentShapeImg = getCurrentShapeImage();
                if (currentShapeImg != null) {
                    g.drawImage(currentShapeImg, shapeX, shapeY, shapeSize, shapeSize, this);
                }

                // Draw slots (only for regular shapes)
                if (!isCurrentShapeIrregular) {
                    drawSlots(g);
                }

                // Draw obstacles
                if (leaf != null) g.drawImage(leaf, leafX, leafY, leafSize, leafSize, this);
                if (tree != null) g.drawImage(tree, treeX, treeY, treeSize, treeSize, this);
                if (stone != null) g.drawImage(stone, stoneX, stoneY, stoneSize, stoneSize, this);
                if (spweb != null) g.drawImage(spweb, spwebX, spwebY, spwebSize, spwebSize, this);

                // Draw visual guides (only for regular shapes)
                if (!isCurrentShapeIrregular) {
                    drawVisualGuides(g);
                }
            }

            // Draw collected irregular shapes using their loaded images
            for (IrregularShape shape : collectedIrregularShapes) {
                if (shape.image != null) {
                    // Draw the actual loaded image
                    g.drawImage(shape.image, shape.x, shape.y, shapeSize / 2, shapeSize / 2, this);
                } else {
                    // Fallback to colored rectangle if image is null
                    g.setColor(shape.color);
                    g.fillRect(shape.x, shape.y, shapeSize / 2, shapeSize / 2);
                    g.setColor(Color.BLACK);
                    g.setFont(new Font("Arial", Font.PLAIN, 8));
                    if (shape.type != null && shape.type.length() > 0) {
                        g.drawString(shape.type.substring(0, 1), shape.x + 5, shape.y + 15);
                    }
                }
            }

            // Draw game stats
            if (gameStarted) {
                drawGameStats(g);
            }

            // Draw game over/win screens
            if (gameOver) {
                drawGameOverScreen(g);
            } else if (gameWin) {
                drawWinScreen(g);
            }
        } catch (Exception e) {
            System.err.println("Error in paintComponent: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void drawSlots(Graphics g) {
        try {
            for (int i = 0; i < slotShape.length; i++) {
                if (slotShape[i] == null) continue;

                switch (slotShape[i]) {
                    case "Hexagon":
                        g.setColor(new Color(73, 0, 90));
                        int[] hexX = new int[6];
                        int[] hexY = new int[6];
                        int centerX = slotPos[i] + shapeSize / 2;
                        int centerY = slotY + shapeSize / 2;
                        int radius = shapeSize / 2 - 2;
                        for (int j = 0; j < 6; j++) {
                            double angle = 2 * Math.PI * j / 6;
                            hexX[j] = centerX + (int) (radius * Math.cos(angle));
                            hexY[j] = centerY + (int) (radius * Math.sin(angle));
                        }
                        g.fillPolygon(hexX, hexY, 6);
                        if (currentShape != null && currentShape.equals("Hexagon")) {
                            g.setColor(Color.ORANGE);
                            g.drawPolygon(hexX, hexY, 6);
                        }
                        break;
                    case "Nonagon":
                        g.setColor(new Color(0x00233C));
                        int[] nonX = new int[9];
                        int[] nonY = new int[9];
                        centerX = slotPos[i] + shapeSize / 2;
                        centerY = slotY + shapeSize / 2;
                        radius = shapeSize / 2 - 2;
                        for (int j = 0; j < 9; j++) {
                            double angle = 2 * Math.PI * j / 9 - Math.PI / 2;
                            nonX[j] = centerX + (int) (radius * Math.cos(angle));
                            nonY[j] = centerY + (int) (radius * Math.sin(angle));
                        }
                        g.fillPolygon(nonX, nonY, 9);
                        if (currentShape != null && currentShape.equals("Nonagon")) {
                            g.setColor(Color.ORANGE);
                            g.drawPolygon(nonX, nonY, 9);
                        }
                        break;
                    case "Heart":
                        if (heart!= null) {
                            g.drawImage(heart, slotPos[i], slotY, shapeSize, shapeSize, this);
                        }
                        if (currentShape.equals("Heart")) { // Corrected casing
                            g.setColor(Color.ORANGE);
                            g.drawRect(slotPos[i] - tolerance, slotY - tolerance,
                                    shapeSize + (tolerance * 2), shapeSize + (tolerance * 2));
                        }
                        break;
                }
            }
        } catch (Exception e) {
            System.err.println("Error in drawSlots: " + e.getMessage());
        }
    }

    private void drawVisualGuides(Graphics g) {
        try {
            int targetSlotX = getTargetSlotX();
            if (targetSlotX != -1) {
                g.setColor(new Color(255, 255, 0, 50));
                // Vertical guide
                if (Math.abs(shapeX - targetSlotX) <= visualGuide) {
                    g.fillRect(targetSlotX, 0, shapeSize, panelHeight);
                }
                // Horizontal guide
                if (Math.abs(shapeY - slotY) <= visualGuide) {
                    g.fillRect(0, slotY, panelWidth, shapeSize);
                }
                // Perfect alignment indicator
                if (Math.abs(shapeX - targetSlotX) <= tolerance && Math.abs(shapeY - slotY) <= tolerance) {
                    g.setColor(new Color(0, 255, 0, 100));
                    g.fillRect(targetSlotX - 2, slotY - 2, shapeSize + 4, shapeSize + 4);
                }
            }
        } catch (Exception e) {
            System.err.println("Error in drawVisualGuides: " + e.getMessage());
        }
    }

    private void drawGameStats(Graphics g) {
        try {
            g.setColor(new Color(0, 0, 0, 180));
            g.fillRoundRect(700, 50, 250, 350, 20, 20);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 16));
            int tX = 715;
            int tY = 70;
            int gapText = 20;

            g.setColor(Color.YELLOW);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            g.drawString("LEVEL 5 ", tX, tY);

            g.setColor(Color.WHITE);
            g.setFont(new Font("Segoe UI Emoji", Font.BOLD, 14));
            g.drawString("Score: " + score, tX, tY + gapText);
            g.drawString("Regular Sorted: " + sorted + "/" + totalToWin, tX, tY + gapText * 2);
            g.drawString("Irregular Collected: " + irregularCollected, tX, tY + gapText * 3);
            g.drawString("Time: " + timeLeft + "s", tX, tY + gapText * 4);

            g.setColor(Color.CYAN);
            g.drawString("Regular Shapes:", tX, tY + gapText * 6);
            g.setColor(Color.WHITE);
            g.drawString("Heart ✓" + heartSort + " ✗" + missedHeart, tX, tY + gapText * 7);
            g.drawString("Hexagon ✓" + hexagonSort + " ✗" + missedHexagon, tX, tY + gapText * 8);
            g.drawString("Nonagon ✓" + nonagonSort + " ✗" + missedNonagon, tX, tY + gapText * 9);

            if (gameStarted) {
                g.setColor(Color.MAGENTA);
                g.drawString("Current Shape:", tX, tY + gapText * 11);
                g.setColor(isCurrentShapeIrregular ? Color.ORANGE : Color.WHITE);
                String shapeText = currentShape != null ? currentShape : "None";
                g.drawString(shapeText + (isCurrentShapeIrregular ? " (Irregular)" : " (Regular)"), tX, tY + gapText * 12);
            }
        } catch (Exception e) {
            System.err.println("Error in drawGameStats: " + e.getMessage());
        }
    }

    private void drawGameOverScreen(Graphics g) {
        try {
            g.setColor(new Color(0, 0, 0, 200));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 48));

            String gameOverText = "GAME OVER";

            g.drawString(gameOverText, panelWidth/2, panelHeight / 2 - 50);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 24));

            String scoreText = "Final Score: " + score;

            g.drawString(scoreText, panelWidth/2-50, panelHeight / 2);
            restart.setVisible(true);
            backToMenu.setVisible(true);
        } catch (Exception e) {
            System.err.println("Error in drawGameOverScreen: " + e.getMessage());
        }
    }

    private void drawWinScreen(Graphics g) {
        try {
            g.setColor(new Color(0, 100, 0, 200));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(Color.YELLOW);
            g.setFont(new Font("Arial", Font.BOLD, 48));

            String winText = "YOU WIN!!";

            g.drawString(winText, panelWidth/2, panelHeight / 2 - 50);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 24));

            String scoreText = "Score: " + score + " | Irregular: " + irregularCollected;

            g.drawString(scoreText, panelWidth/2-50, panelHeight / 2);
            restart.setVisible(true);
            backToMenu.setVisible(true);
        } catch (Exception e) {
            System.err.println("Error in drawWinScreen: " + e.getMessage());
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        if (!gameStarted || gameWin || gameOver) {
            return;
        }

        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                shapeX -= 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_RIGHT:
                shapeX += 10;
                freezeShape = false;
                break;
            case KeyEvent.VK_UP: // Fine tune left
                shapeX -= 1;
                freezeShape = false;
                break;
            case KeyEvent.VK_DOWN: // Fine tune right
                shapeX += 1;
                freezeShape = false;
                break;
        }

        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    public int getScore() {
        return score;
    }

    // Method to be called when this panel becomes visible
    public void onPanelShown() {
        requestFocusInWindow();
        repaint();
    }
}
